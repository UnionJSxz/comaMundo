-- https://lua.expert

local GuiService = game:GetService("GuiService")
local _ = script.Parent
local v1

function topbar() -- line: 5
    -- upvalues: GuiService (copy), v1 (ref)
    v1 = GuiService:GetGuiInset()
end

GuiService:GetPropertyChangedSignal("TopbarInset"):Connect(topbar)
topbar()

local UserInputService = game:GetService("UserInputService")
local t1 = {
    ["Chaos Canyon"] = "rbxassetid://13003684897",
    ["Candy Land"] = "rbxassetid://18755162385",
    ["Block Town"] = "rbxassetid://18755163856",
    ["Haunted Mansion"] = "rbxassetid://18755156400",
    Headquarters = "rbxassetid://18755155676",
    ["Glass Houses"] = "rbxassetid://18755157086",
    Jungle = "rbxassetid://18755155056",
    ["Battle Zone"] = "rbxassetid://18755164558",
    ["Blox City"] = "rbxassetid://18755163196",
    ["Community Construction"] = "rbxassetid://18755160860",
    Courtyard = "rbxassetid://18755159842",
    ["Forest Peak"] = "rbxassetid://18755157745",
    ["Mega Baseplate"] = "rbxassetid://18755154343",
    ["Ninja Temple"] = "rbxassetid://18755153661",
    ["Raven Rock"] = "rbxassetid://18755152884",
    ["Town of Robloxia"] = "rbxassetid://18755152200",
    Studville = "rbxassetid://18755151491",
    ["Zombie Town"] = "rbxassetid://116856733034056",
    ["Yorick's Resting Place"] = "rbxassetid://114408032018779",
    ["Christmas Coast"] = "rbxassetid://133020933747696",
    ["Winter Workshop"] = "rbxassetid://98710295823320",
    ["Snow Land"] = "rbxassetid://71656374728983",
    ["Castle Playground"] = "rbxassetid://109209496178674",
    ["Mini Baseplate"] = "rbxassetid://126683491832842",
    Twister = "rbxassetid://129328343279131",
    ["Grid City"] = "rbxassetid://140153575402050",
    ["Mega Grid"] = "rbxassetid://135823487152856",
    ["Middle Robloxia"] = "rbxassetid://91068414593206",
    ["Martian Madness"] = "rbxassetid://92378478461784"
}
local MapVote = game.ReplicatedStorage.Events.MapVote
local Template = script.Parent.MapButtons.Template
local VoteTemplate = Template.VoteTemplate

VoteTemplate.Parent = script
Template.Parent = script

local v2 = TweenInfo.new(0.3, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out, 0, false, 0)
local TweenService = game:GetService("TweenService")

script.Parent.Parent:WaitForChild("MapCountdown"):WaitForChild("Clock")
MapVote.OnClientEvent:Connect(function(p1) -- line: 66
    -- upvalues: v1 (ref), UserInputService (copy), t1 (copy), MapVote (copy), Template (copy)
    for _, child in ipairs(script.Parent.MapButtons:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy()
        end
    end

    script.Parent.Visible = true

    for v3, v4 in ipairs(p1) do
        local clone = Template:Clone()

        clone.Name = v3
        clone.Title.Text = v4
        clone.LayoutOrder = v3

        local v5 = t1[v4]

        if v5 then
            clone.ImageButton.Image = v5
        end

        clone.ImageButton.Activated:Connect(function() -- line: 83
            -- upvalues: clone (copy), v3 (copy), v1 (ref), UserInputService (copy), MapVote (copy)
            MapVote:FireServer(v3, (UserInputService:GetMouseLocation() - v1 - clone.AbsolutePosition) / clone.AbsoluteSize)
        end)
        clone.Parent = script.Parent.MapButtons
    end
end)

local n1 = 1000

function positionVote(p2, p3, p4) -- line: 96
    -- upvalues: n1 (ref)
    local v8 = math.floor(p3.Z + 0.5)

    p2.Parent = script.Parent.MapButtons[tostring(v8)]
    p2.Position = UDim2.new(p3.X, 0, p3.Y, 0)
    p2.Size = UDim2.new(0.2, 0, 0.2, 0)
    p4:Play()
    n1 += 1
    p2.ZIndex = n1
end

game.ReplicatedStorage.MapVotes.ChildAdded:Connect(function(p5) -- line: 107
    -- upvalues: VoteTemplate (copy), v2 (copy), TweenService (copy)
    local v9 = game.Players:FindFirstChild(p5.Name)

    if not v9 then
        return
    end

    local clone = VoteTemplate:Clone()

    clone.PlayerImage.Image = game.Players:GetUserThumbnailAsync(v9.UserId, Enum.ThumbnailType.AvatarThumbnail, Enum.ThumbnailSize.Size150x150)

    local tween = TweenService:Create(clone, v2, {
        Size = UDim2.new(0.7, 0, 0.7, 0)
    })

    positionVote(clone, p5.Value, tween)
    p5.Changed:Connect(function() -- line: 114
        -- upvalues: p5 (copy), clone (copy), tween (copy)
        positionVote(clone, p5.Value, tween)
    end)
end)

function ms(p6) -- line: 119
    script.Parent.EventMessage.Text = p6
end

function mn(p7) -- line: 123
    script.Parent.MapName.Text = p7
end

function mt(p8) -- line: 126
    if not (p8 < 0) then
        return
    end

    script.Parent.Visible = false

    for _, child in ipairs(script.Parent.MapButtons:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy()
        end
    end
end

local MapTime = game.ReplicatedStorage.ServerSettings.MapTime

MapTime.Changed:Connect(mt)
mt(MapTime.Value)
