-- https://lua.expert

local MarketplaceService = game:GetService("MarketplaceService")

game:GetService("TextService")

local ItemInfo = require(game.ReplicatedStorage.ItemInfo)
local Tabs = script.Parent.Tabs
local PurchaseEvent, _, _, SummonEvent = game.ReplicatedStorage.Events.PurchaseEvent, game.ReplicatedStorage.Events.SetCubes, game.ReplicatedStorage.Events.CubesAdded, game.ReplicatedStorage.Events.SummonEvent

Color3.new(0, 1, 0)

local v1 = Color3.new(0.4, 0.4, 0.4)
local v2 = Color3.new(0.8, 0.8, 0.8)

Color3.new(1, 0.717647, 0.223529)

local LocalPlayer = game.Players.LocalPlayer
local _ = LocalPlayer.Character
local UpgradeList = script.Parent.ShopFrames.Upgrades.UpgradeList
local Template = script.Parent.ShopFrames.Upgrades.UpgradeList.Template

Template.Parent = nil

local Robux = script.Parent.ShopFrames.Robux
local Gamepasses, Cubes, Tokens = Robux.Gamepasses, Robux.Cubes, Robux.Tokens
local Template2 = Gamepasses.Template
local Template3 = Cubes.Template
local Template4 = Tokens.Template

Template2.Parent = nil
Template3.Parent = nil
Template4.Parent = nil

local Events = script.Parent.ShopFrames.Events
local Tokens2, EventList = Events.Tokens, Events.EventList
local Template5 = EventList.Template

Template5.Parent = nil

local Upgrades = LocalPlayer:WaitForChild("Upgrades")

function commaValue(p1) -- line: 46
    repeat
        local v4

        p1, v4 = string.gsub(p1, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v4 == 0

    return p1
end

function formatImage(p2, _) -- line: 58
    p2.ImageLabel.Position = UDim2.new(0.45, -p2.TextBounds.X / 2, 0.5, 0)
    p2.Position = UDim2.new(0.55, p2.ImageLabel.AbsoluteSize.X / 2, 0, 0)

    local v5 = p2.Parent.AbsolutePosition.X + p2.Parent.AbsoluteSize.X
    local v6 = p2.AbsolutePosition.X + p2.AbsoluteSize.X - v5

    if v6 > 0 then
        p2.Position = UDim2.new(0.55, p2.ImageLabel.AbsoluteSize.X / 2 - v6, 0, 0)
    end
end

local n1 = 0

function setCubes(p4) -- line: 77
    -- upvalues: n1 (ref)
    n1 = p4
    script.Parent.CubeFrame.CounterFrame.Cubes.Text = commaValue(p4)
end

local SetCubes, CubesAdded = game.ReplicatedStorage.Events.SetCubes, game.ReplicatedStorage.Events.CubesAdded
local SoundModule = require(game.ReplicatedStorage.SoundModule)
local Sell = SoundModule.newSound(script, "Sell")
local Error = SoundModule.newSound(script, "Error")

CubesAdded.OnClientEvent:Connect(function(p5, p6) -- line: 88
    -- upvalues: Sell (copy)
    if p5 < 0 then
        Sell:Play()
    end

    setCubes(p6)
end)
SetCubes.OnClientEvent:Connect(function(p7) -- line: 96
    setCubes(p7)
end)
Color3.fromRGB(209, 0, 0)

local v7 = Color3.fromRGB(82, 176, 77)
local v8 = Color3.fromRGB(95, 200, 88)

Color3.fromRGB(208, 68, 72)

function turnOff(p8, p9) -- line: 105
    -- upvalues: v1 (copy), v2 (copy)
    p8.BackgroundColor3 = v1

    if p9 then
        p8.Text = p9
    end

    p8.UIStroke.Color = v2
end

function turnOn(p10, p11) -- line: 114
    -- upvalues: v7 (copy), v8 (copy)
    p10.BackgroundColor3 = v7
    p10.UIStroke.Color = v8

    if p11 then
        (if p10:IsA("TextButton") then p10 else p10:FindFirstChild("TextLabel")).Text = p11
    end
end

function updateTokensFrame() -- line: 129
    -- upvalues: Tokens2 (copy)
    local TokensFrame = script.Parent.ShopFrames.Robux:FindFirstChild("TokensFrame")

    if TokensFrame then
        TokensFrame:Destroy()
    end

    if script.Parent.ShopFrames.Robux.Tokens.Visible then
        local clone = Tokens2:Clone()

        clone.Name = "TokensFrame"
        clone.Parent = script.Parent.ShopFrames.Robux
        clone.Position = UDim2.new(0.5, 0, 0.308, 0)
    end
end

function openTab(p12) -- line: 142
    -- upvalues: Tabs (copy)
    for _, child in ipairs(Tabs:GetChildren()) do
        if child:IsA("GuiButton") then
            turnOff(child)
            script.Parent.ShopFrames[child.Name].Visible = false
        end
    end

    if p12 ~= "Cubes" and p12 ~= "Gamepasses" and p12 ~= "Tokens" then
        if Tabs:FindFirstChild(p12) then
            turnOn(Tabs[p12])
        end

        script.Parent.ShopFrames[p12].Visible = true
    else
        turnOn(Tabs.Robux)
        script.Parent.ShopFrames.Robux.Visible = true
        script.Parent.ShopFrames.Robux.Gamepasses.Visible = false
        script.Parent.ShopFrames.Robux.Cubes.Visible = false
        script.Parent.ShopFrames.Robux.Tokens.Visible = false
        turnOff(script.Parent.ShopFrames.Robux.Tabs.Gamepasses)
        turnOff(script.Parent.ShopFrames.Robux.Tabs.Cubes)

        if script.Parent.ShopFrames.Robux.Tabs:FindFirstChild(p12) then
            turnOn(script.Parent.ShopFrames.Robux.Tabs[p12])
        end

        script.Parent.ShopFrames.Robux[p12].Visible = true
        updateTokensFrame()
    end
end

for _, child in ipairs(Tabs:GetChildren()) do
    if child:IsA("GuiButton") then
        child.Activated:Connect(function() -- line: 175
            -- upvalues: child (copy)
            openTab(child.Name)
        end)
    end
end

function loadUpgrades() -- line: 181
    -- upvalues: ItemInfo (copy), PurchaseEvent (copy), UpgradeList (copy), Template (copy), Upgrades (copy), n1 (ref), Error (copy)
    for _, child in ipairs(UpgradeList:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy()
        end
    end

    for _, child in ipairs(Upgrades:GetChildren()) do
        local clone = Template:Clone()
        local v9 = ItemInfo.Upgrades[child.Name]

        if v9 then
            clone.Title.Text = string.upper(v9.name)
            clone.LayoutOrder = v9.order
            clone.BuyFrame.Button.Activated:Connect(function() -- line: 193
                -- upvalues: child (copy), v9 (copy), PurchaseEvent (copy), n1 (ref), Error (copy)
                PurchaseEvent:FireServer(child.Name)

                if n1 < v9.priceFunction(child.Value + 1) then
                    Error:Play()
                end
            end)
            child.Changed:Connect(updateUpgrades)
            clone.Name = child.Name
            clone.Parent = UpgradeList
            print("added to upgrade list!")
            continue
        end

        warn("NO UPGRADE INFO FOUND")
    end
end

function updateUpgrades() -- line: 205
    -- upvalues: ItemInfo (copy), UpgradeList (copy), Upgrades (copy)
    for _, child in ipairs(Upgrades:GetChildren()) do
        if child:IsA("NumberValue") or child:IsA("IntValue") then
            local v11 = ItemInfo.Upgrades[child.Name]

            if v11 then
                local v12 = UpgradeList:FindFirstChild(child.Name)

                if v12 then
                    v12.UpgradeFrame.Level.Text = "LEVEL " .. child.Value
                    v12.UpgradeFrame.Amount.Text = commaValue(v11.growthFunction(child.Value))
                    v12.ImageLabel.Image = v11.image
                    v12.Glow.ImageColor3 = v11.color
                    v12.BuyFrame.Price.Text = commaValue(v11.priceFunction(child.Value + 1))
                    formatImage(v12.BuyFrame.Price)
                else
                    warn("NO UPGRADE FRAME FOUND")
                end
            else
                warn("NO UPGRADE INFO FOUND " .. child.Name)
            end
        end
    end
end

function resizeUpgrades() -- line: 222
    -- upvalues: UpgradeList (copy), Tokens2 (copy)
    for _, child in ipairs(UpgradeList:GetChildren()) do
        local BuyFrame = child:FindFirstChild("BuyFrame")

        if BuyFrame then
            formatImage(BuyFrame.Price)
        end
    end

    Tokens2.Size = UDim2.new(0, Tokens2.Tokens.AbsoluteSize.X + Tokens2.ImageLabel.AbsoluteSize.X + Tokens2.AbsoluteSize.Y / 2, 0.15, 0)
    Tokens2.UIListLayout.Padding = UDim.new(0, Tokens2.AbsoluteSize.Y / 4)
    Tokens2.Parent.Add.Position = UDim2.new(0, Tokens2.AbsolutePosition.X + Tokens2.AbsoluteSize.X - Tokens2.Parent.AbsolutePosition.X + 8, 0, Tokens2.AbsolutePosition.Y + Tokens2.AbsoluteSize.Y / 2 - Tokens2.Parent.AbsolutePosition.Y + 1)
    updateTokensFrame()
end

Tabs:GetPropertyChangedSignal("AbsoluteSize"):Connect(resizeUpgrades)

local UserInputService = game:GetService("UserInputService")

UserInputService.WindowFocused:Connect(resizeUpgrades)
UserInputService.WindowFocusReleased:Connect(resizeUpgrades)

function updateTokens(p13) -- line: 239
    -- upvalues: Tokens2 (copy)
    p13 = p13 or nil
    Tokens2.Tokens.Text = commaValue(p13)
    resizeUpgrades()
end

local Tokens3 = LocalPlayer:WaitForChild("Tokens")

Tokens3.Changed:Connect(updateTokens)

function loadRobux() -- line: 250
    -- upvalues: MarketplaceService (copy), ItemInfo (copy), PurchaseEvent (copy), LocalPlayer (copy), Robux (copy), Gamepasses (copy), Cubes (copy), Tokens (copy), Template2 (copy), Template3 (copy), Template4 (copy), Tokens2 (copy)
    for v14, v15 in pairs(ItemInfo.GamePasses) do
        local v16 = nil

        local function v17() -- line: 253
            -- upvalues: v16 (ref), v15 (copy), MarketplaceService (copy)
            v16 = MarketplaceService:GetProductInfo(v15, Enum.InfoType.GamePass)
        end

        pcall(v17)

        if v16 and v16.PriceInRobux then
            local clone = Template2:Clone()

            clone.Name = v14
            clone.LayoutOrder = v16.PriceInRobux
            clone.Size = UDim2.new(0.3333333333333333, -6, 1, 0)
            clone.Title.Text = string.upper(v14)
            clone.Price.Text = "" .. commaValue(v16.PriceInRobux)

            if ItemInfo.Descriptions[v14] then
                clone.Description.Text = ItemInfo.Descriptions[v14]
            end

            if v16.IconImageAssetId then
                clone.ItemImage.Image = "rbxassetid://" .. v16.IconImageAssetId
            end

            local Gamepasses2 = LocalPlayer:WaitForChild("Gamepasses")

            if Gamepasses2 then
                local v18 = Gamepasses2:WaitForChild(v14)

                if v18 then
                    if v18.Value then
                        turnOff(clone.Buy, "purchased")
                    else
                        v18.Changed:Connect(function(p14) -- line: 278
                            -- upvalues: clone (copy)
                            if p14 then
                                turnOff(clone.Buy, "purchased")
                            end
                        end)
                    end
                end
            end

            clone.Button.Activated:Connect(function() -- line: 286
                -- upvalues: v14 (copy), PurchaseEvent (copy)
                PurchaseEvent:FireServer(v14)
            end)
            clone.Buy.Activated:Connect(function() -- line: 289
                -- upvalues: v14 (copy), PurchaseEvent (copy)
                PurchaseEvent:FireServer(v14)
            end)
            clone.Parent = Gamepasses
        end
    end

    for v19, v20 in pairs(ItemInfo.CubePacks) do
        local v21 = nil

        local function v22() -- line: 298
            -- upvalues: v21 (ref), v19 (copy), MarketplaceService (copy), ItemInfo (copy)
            v21 = MarketplaceService:GetProductInfo(ItemInfo.DevProducts[v19], Enum.InfoType.Product)
        end

        pcall(v22)

        if v21 and v21.PriceInRobux then
            local clone = Template3:Clone()

            clone.LayoutOrder = v20
            clone.Name = v19
            clone.Size = UDim2.new(0.25, -9, 1, 0)
            clone.Title.Text = commaValue(v20)
            clone.Price.Text = "" .. commaValue(v21.PriceInRobux)

            local v24 = math.floor((v20 / v21.PriceInRobux / (ItemInfo.CubePacks["Small Cube Pack"] / 70) - 1) * 100)

            if v20 == ItemInfo.CubePacks["Small Cube Pack"] then
                clone.Description.Visible = false
            else
                clone.Description.Text = v24 .. "% Extra!"
            end

            if v21.IconImageAssetId then
                clone.ItemImage.Image = "rbxassetid://" .. v21.IconImageAssetId
            end

            clone.Button.Activated:Connect(function() -- line: 318
                -- upvalues: v19 (copy), PurchaseEvent (copy)
                PurchaseEvent:FireServer(v19)
            end)
            clone.Buy.Activated:Connect(function() -- line: 321
                -- upvalues: v19 (copy), PurchaseEvent (copy)
                PurchaseEvent:FireServer(v19)
            end)
            clone.Parent = Cubes
        end
    end

    for v25, v26 in pairs(ItemInfo.TokenPacks) do
        local v27 = nil

        local function v28() -- line: 330
            -- upvalues: v27 (ref), v25 (copy), MarketplaceService (copy), ItemInfo (copy)
            v27 = MarketplaceService:GetProductInfo(ItemInfo.DevProducts[v25], Enum.InfoType.Product)
        end

        pcall(v28)

        if v27 and v27.PriceInRobux then
            local clone = Template4:Clone()

            clone.LayoutOrder = v26
            clone.Name = v25
            clone.Size = UDim2.new(0.25, -9, 0.8, 0)
            clone.Title.Text = commaValue(v26)
            clone.Price.Text = "" .. commaValue(v27.PriceInRobux)
            clone.Description.Visible = false

            if v27.IconImageAssetId then
                clone.ItemImage.Image = "rbxassetid://" .. v27.IconImageAssetId
            end

            clone.Button.Activated:Connect(function() -- line: 350
                -- upvalues: v25 (copy), PurchaseEvent (copy)
                PurchaseEvent:FireServer(v25)
            end)
            clone.Buy.Activated:Connect(function() -- line: 353
                -- upvalues: v25 (copy), PurchaseEvent (copy)
                PurchaseEvent:FireServer(v25)
            end)
            clone.Parent = Tokens
        end
    end

    Robux.Tabs.Gamepasses.Activated:Connect(function() -- line: 359
        openTab("Gamepasses")
    end)
    Robux.Tabs.Cubes.Activated:Connect(function() -- line: 362
        openTab("Cubes")
    end)
    Tokens2.Parent.Add.Activated:Connect(function() -- line: 365
        openTab("Tokens")
    end)
    script.Parent.Parent.Inventory.TokenFrame.CounterFrame.Add.Activated:Connect(function() -- line: 369
        script.Parent.Parent.Inventory.Visible = false
        script.Parent.Visible = true
        openTab("Tokens")
    end)
end

function loadEvents() -- line: 377
    -- upvalues: ItemInfo (copy), PurchaseEvent (copy), SummonEvent (copy), EventList (copy), Template5 (copy), Error (copy), Tokens3 (copy)
    for v29, v30 in pairs(ItemInfo.Events) do
        local price = v30.price

        if price then
            local clone = Template5:Clone()

            clone.Name = v29
            clone.LayoutOrder = price
            clone.Title.Text = string.upper(v29)
            clone.BuyFrame.Price.Text = commaValue(price)
            clone.ItemImage.Image = v30.image
            clone.Activated:Connect(function() -- line: 390
                -- upvalues: price (copy), v29 (copy), ItemInfo (copy), PurchaseEvent (copy), SummonEvent (copy), Error (copy), Tokens3 (copy)
                if not (Tokens3.Value < price) then
                    SummonEvent:FireServer(v29)

                    return
                end

                Error:Play()

                local v31 = price - Tokens3.Value
                local v32 = "Giant Token Pack"

                for v33, v34 in pairs(ItemInfo.TokenPacks) do
                    if v31 <= v34 and v34 <= ItemInfo.TokenPacks[v32] then
                        v32 = v33
                    end
                end

                PurchaseEvent:FireServer(v32)
            end)
            clone.Parent = EventList
        end
    end
end

script.Parent.Done.Activated:Connect(function() -- line: 410
    script.Parent.Visible = false
end)
loadUpgrades()
loadEvents()
updateUpgrades()
loadRobux()
openTab("Gamepasses")
openTab("Upgrades")
updateTokens(Tokens3.Value)

if game.PlaceId == 15134674256 or game.PlaceId == 18504777118 then
    script.Parent.ShopFrames.Upgrades.Offers.MaxSize.Visible = false
end
