-- https://lua.expert

local Parent = script.Parent

game:GetService("TextService")

local _ = Parent.CounterFrame.TextLabel.Font

Vector2.new(1000, 100)
workspace:WaitForChild("CubeSpin"):WaitForChild("CubeSpin")

local Cube = script.Parent.CounterFrame.ImageLabel.ImageLabel.Cube
local SetCubes, CubesAdded = game.ReplicatedStorage.Events.SetCubes, game.ReplicatedStorage.Events.CubesAdded
local v1 = false
local TweenService = game:GetService("TweenService")
local v2 = TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
local v3 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0, false, 0)
local v4 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
local v5 = TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, 0)

TweenInfo.new(5, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1, false, 0)
TweenInfo.new(2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, 0)

local tween = TweenService:Create(Parent.CounterFrame, v4, {
    Position = UDim2.new(0.5, 0, 0.3, 0)
})
local tween2 = TweenService:Create(Parent.CounterFrame, v5, {
    Position = UDim2.new(0.5, 0, 0.4, 0)
})
local tween3 = TweenService:Create(Parent.AddCubes, v2, {
    Size = UDim2.new(1, 0, 0.3, 0)
})
local tween4 = TweenService:Create(Parent.AddCubes, v3, {
    Position = UDim2.new(0.5, 0, 0.4, 0)
})
local v6 = false
local t1 = {}
local n1 = 0
local n2 = 0
local n3 = 0

SetCubes.OnClientEvent:Connect(function(p1) -- line: 41
    -- upvalues: v1 (ref), n1 (ref), n2 (ref)
    v1 = true

    if n1 > 0 and n1 ~= p1 then
        print("Disparity in Cube display!")
    end

    n1 = p1
    n2 = p1
    setGUI()
end)
SetCubes:FireServer()
tween.Completed:Connect(function() -- line: 52
    -- upvalues: tween2 (copy)
    tween2:Play()
end)

function commaValue(p2) -- line: 56
    repeat
        local v8

        p2, v8 = string.gsub(p2, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v8 == 0

    return p2
end

function setGUI() -- line: 68
    -- upvalues: Parent (copy), n2 (ref)
    local v9 = commaValue(n2)

    Parent.CounterFrame.TextLabel.Text = v9
    Parent.CounterFrame.ImageLabel.Position = UDim2.new(0.5, -Parent.CounterFrame.TextLabel.TextBounds.X / 2, 0, 0)
end

workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(setGUI)

local UserInputService = game:GetService("UserInputService")

UserInputService.WindowFocused:Connect(setGUI)
UserInputService.WindowFocusReleased:Connect(setGUI)

function addCubes(p3, p4) -- line: 85
    -- upvalues: Parent (copy), v1 (ref), tween (copy), tween3 (copy), tween4 (copy), v6 (ref), t1 (copy), n1 (ref), n3 (ref)
    n3 = 0

    if v6 and not p4 or not v1 then
        table.insert(t1, p3)

        return
    end

    v6 = true
    Parent.CounterFrame.TextLabel.TextStrokeTransparency = 0.4
    Parent.CounterFrame.ImageLabel.ImageLabel.ImageTransparency = 0
    Parent.CounterFrame.ImageLabel.Outline.ImageTransparency = 0.45
    Parent.CounterFrame.TextLabel.TextTransparency = 0
    Parent.Visible = true
    Parent.AddCubes.Visible = true
    Parent.AddCubes.Text = "+" .. commaValue(p3)
    Parent.AddCubes.Size = UDim2.new(0.1, 0, 0.03, 0)
    Parent.AddCubes.Position = UDim2.new(0.5, 0, 0.8, 0)
    tween3:Cancel()
    tween4:Cancel()
    tween3:Play()
    wait(0.3)
    tween4:Play()
    wait(0.15)
    Parent.AddCubes.Visible = false
    n1 += p3
    tween:Play()
    wait(0.05)

    if #t1 > 0 then
        local v10 = t1[1]

        table.remove(t1, 1)
        addCubes(v10, true)
    end

    if not p4 then
        v6 = false
    end
end

CubesAdded.OnClientEvent:Connect(function(p5, p6) -- line: 124
    -- upvalues: n1 (ref), n2 (ref)
    if p5 > 0 then
        addCubes(p5)
    else
        n1 = p6
        n2 = p6
        setGUI()
    end
end)
game["Run Service"].Heartbeat:Connect(function() -- line: 135
    -- upvalues: n1 (ref), n2 (ref), n3 (ref)
    if n2 == n1 then
        return
    end

    n3 = 0

    local v12 = n1 - n2

    if v12 > 10000 then
        n2 += 1000
    elseif v12 > 5000 then
        n2 += 500
    elseif v12 > 1000 then
        n2 += 100
    elseif v12 > 500 then
        n2 += 50
    elseif v12 > 100 then
        n2 += 10
    elseif v12 > 50 then
        n2 += 5
    else
        n2 += 1
    end

    if v12 < 0 then
        n2 = n1
    end

    setGUI()
end)
spawn(function() -- line: 160
    -- upvalues: Parent (copy), SetCubes (copy), n3 (ref)
    while true do
        wait(1)

        local v14

        if not (n3 > 5) then
            v14 = n3
            n3 = v14 + 1
            continue
        end

        for i = 1, 10 do
            if n3 < 5 then
                break
            end

            Parent.CounterFrame.ImageLabel.ImageLabel.ImageTransparency = i * 0.1
            Parent.CounterFrame.ImageLabel.Outline.ImageTransparency = i * 0.2 + 0.2
            Parent.CounterFrame.TextLabel.TextStrokeTransparency = i * 0.2 + 0.2
            Parent.CounterFrame.TextLabel.TextTransparency = i * 0.1
            wait(0.1)
        end

        if n3 > 5 then
            Parent.Visible = false
            SetCubes:FireServer()
        end

        v14 = n3
        n3 = v14 + 1
    end
end)
game["Run Service"].RenderStepped:Connect(function(p7) -- line: 181
    -- upvalues: Cube (copy)
    if Cube then
        Cube:FindFirstChild("Weld")
    end

    Cube.Visual.Orientation = Cube.Visual.Orientation + Vector3.new(0, p7 * 50, 0)
    Cube.Parent.Parent.Outline.Cube.Visual.Orientation = Cube.Visual.Orientation
end)
