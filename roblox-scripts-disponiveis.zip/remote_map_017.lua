-- https://lua.expert

game:GetService("MarketplaceService")
game:GetService("TextService")

local ItemInfo = require(game.ReplicatedStorage.ItemInfo)
local Tabs = script.Parent.Tabs
local _, _, _, _ = game.ReplicatedStorage.Events.PurchaseEvent, game.ReplicatedStorage.Events.SetCubes, game.ReplicatedStorage.Events.CubesAdded, game.ReplicatedStorage.Events.SummonEvent
local SetNametag = game.ReplicatedStorage.Events.SetNametag
local v1 = Color3.fromRGB(209, 0, 0)
local v2 = Color3.fromRGB(82, 176, 77)

Color3.new(0, 1, 0)

local v3 = Color3.new(0.4, 0.4, 0.4)
local v4 = Color3.new(0.8, 0.8, 0.8)

Color3.new(1, 0.717647, 0.223529)

local LocalPlayer = game.Players.LocalPlayer
local _ = LocalPlayer.Character
local Nametags = LocalPlayer:WaitForChild("Nametags")
local Nametag = LocalPlayer:WaitForChild("Nametag")

LocalPlayer:WaitForChild("Upgrades")

local Nametags2 = game.ReplicatedStorage:WaitForChild("Nametags")
local Nametags3 = script.Parent.InventoryFrames.Inventory.Nametags
local Template = Nametags3.Template

Template.Parent = nil

local Description = script.Parent.InventoryFrames.Inventory.Description
local v5 = nil
local v6
local CrateList = script.Parent.InventoryFrames.Crates.CrateList
local Template2 = script.Parent.InventoryFrames.Crates.CrateList.Template

Template2.Parent = nil

local Description2 = script.Parent.InventoryFrames.Crates.Description
local SoundModule = require(game.ReplicatedStorage.SoundModule)

SoundModule.newSound(script, "Sell")
SoundModule.newSound(script, "Error")

function updateEquipped() -- line: 50
    -- upvalues: v1 (copy), v2 (copy), Nametag (copy), Description (copy), v5 (ref)
    local v8 = v5

    v8 = v8 and v5 == Nametag.Value

    if not v8 then
        Description.Container.EquipButton.BackgroundColor3 = v2
        Description.Container.EquipButton.UIStroke.Color = v2
        Description.Container.EquipButton.Text = "EQUIP"
    else
        Description.Container.EquipButton.BackgroundColor3 = v1
        Description.Container.EquipButton.UIStroke.Color = v1
        Description.Container.EquipButton.Text = "UNEQUIP"
    end
end

function commaValue(p1) -- line: 62
    repeat
        local v11

        p1, v11 = string.gsub(p1, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v11 == 0

    return p1
end

local SoundModule2 = require(game.ReplicatedStorage.SoundModule)

SoundModule2.newSound(script, "Sell")

local Error = SoundModule2.newSound(script, "Error")

Color3.fromRGB(209, 0, 0)

local v12 = Color3.fromRGB(82, 176, 77)
local v13 = Color3.fromRGB(95, 200, 88)

Color3.fromRGB(208, 68, 72)

function turnOff(p2, p3) -- line: 83
    -- upvalues: v3 (copy), v4 (copy)
    p2.BackgroundColor3 = v3

    if p3 then
        p2.Text = p3
    end

    p2.UIStroke.Color = v4
end

function turnOn(p4, p5) -- line: 92
    -- upvalues: v12 (copy), v13 (copy)
    p4.BackgroundColor3 = v12
    p4.UIStroke.Color = v13

    if p5 then
        (if p4:IsA("TextButton") then p4 else p4:FindFirstChild("TextLabel")).Text = p5
    end
end

function openTab(p6) -- line: 107
    -- upvalues: Tabs (copy)
    for _, child in ipairs(Tabs:GetChildren()) do
        if child:IsA("GuiButton") then
            turnOff(child)
            script.Parent.InventoryFrames[child.Name].Visible = false
        end
    end

    if Tabs:FindFirstChild(p6) then
        turnOn(Tabs[p6])
    end

    script.Parent.InventoryFrames[p6].Visible = true
end

for _, child in ipairs(Tabs:GetChildren()) do
    if child:IsA("GuiButton") then
        child.Activated:Connect(function() -- line: 123
            -- upvalues: child (copy)
            openTab(child.Name)
        end)
    end
end

local Tokens = script.Parent.TokenFrame.CounterFrame.Tokens

local function updateTokens(p7) -- line: 131
    -- upvalues: Tokens (copy)
    Tokens.Text = commaValue(p7)
end

local Tokens2 = LocalPlayer:WaitForChild("Tokens")

Tokens2.Changed:Connect(updateTokens)

local function resizeNametags() -- line: 140
    -- upvalues: Nametags3 (copy), Description (copy)
    if script.Parent.Visible then
        local Children = Nametags3:GetChildren()

        table.insert(Children, Description.Container.Nametag)

        for _, v14 in ipairs(Children) do
            if v14:IsA("GuiButton") or v14:IsA("Frame") then
                local Frame = v14:FindFirstChildWhichIsA("Frame")

                if Frame then
                    local AbsoluteSize = v14.AbsoluteSize
                    local UpperText = Frame:FindFirstChild("UpperText")
                    local v15 = 20

                    if UpperText then
                        UpperText.TextSize = 14

                        local TextBounds = UpperText.TextBounds
                        local v16 = TextBounds.Y / TextBounds.X

                        UpperText.Size = UDim2.new(1, 0, 1, 0)
                        UpperText.SizeConstraint = Enum.SizeConstraint.RelativeXY
                        UpperText.TextWrapped = false
                        UpperText.TextYAlignment = Enum.TextYAlignment.Center

                        local UIStroke = UpperText:FindFirstChild("UIStroke")
                        local v17 = if UIStroke then UIStroke.Thickness else 1

                        UpperText.TextSize = math.floor(AbsoluteSize.X * v16 - v17)
                        v15 = UpperText.TextSize
                    end

                    local Background = Frame:FindFirstChild("Background")

                    if Background then
                        Background.Size = UDim2.new(1, 0, 0, v15)
                    end

                    local LocalScript = Frame:FindFirstChild("LocalScript")

                    if LocalScript then
                        LocalScript.Enabled = false
                        LocalScript.Enabled = true
                    end
                end
            end
        end
    end
end

local t1 = {
    {
        "Common",
        Color3.new(1, 1, 1)
    },
    {
        "Uncommon",
        Color3.new(0.470588, 1, 0.0666667)
    },
    {
        "RARE",
        Color3.new(1, 0, 0)
    },
    {
        "EVENT",
        Color3.new(1, 0.85098, 0)
    },
    {
        "LEGENDARY",
        Color3.new(0, 0.898039, 1)
    },
    {
        "MYTHIC",
        Color3.new(0.831373, 0, 1)
    }
}

local function loadDescription(p8) -- line: 191
    -- upvalues: ItemInfo (copy), Nametags3 (copy), Description (copy), v5 (ref), resizeNametags (copy), t1 (copy)
    if p8 then
        Description.Container.Visible = true

        if p8 ~= v5 then
            local Frame = Description.Container.Nametag:FindFirstChildWhichIsA("Frame")

            if Frame then
                Frame:Destroy()
            end

            local v19 = Nametags3:FindFirstChild(p8)

            if v19 then
                local Frame = v19:FindFirstChildWhichIsA("Frame")

                if Frame then
                    Frame:Clone().Parent = Description.Container.Nametag
                    Description.Container.Description.Text = ItemInfo.Nametags[p8].description
                    Description.Container.Rarity.Text = t1[ItemInfo.Nametags[p8].rarity][1]
                    Description.Container.Rarity.TextColor3 = t1[ItemInfo.Nametags[p8].rarity][2]
                    v5 = p8
                    updateEquipped()
                    resizeNametags()
                end
            end
        end
    else
        print("description should be hidden!!!")
        Description.Container.Visible = false
        v5 = nil
    end
end

local function loadCrateDescription(p9) -- line: 219
    -- upvalues: ItemInfo (copy), v6 (ref), Description2 (copy)
    if p9 then
        Description2.Container.Visible = true

        if p9 ~= v6 then
            local ViewportFrame = Description2.Container.Icon.ViewportFrame
            local v20 = ItemInfo.Crates[p9]
            local v21 = v20.decal or ""
            local v22 = v20.color or Color3.new(1, 1, 1)

            ViewportFrame.Top.Bottom.Decal.Texture = v21
            ViewportFrame.Top.Decal.Texture = v21
            ViewportFrame.Top.Color = v22
            ViewportFrame.Top.Bottom.Color = v22
            Description2.Container.Description.Text = ItemInfo.Crates[p9].description
            Description2.Container.Title.Text = p9
            v6 = p9
        end
    else
        print("description should be hidden!!!")
        Description2.Container.Visible = false
        v6 = nil
    end
end

Tabs:GetPropertyChangedSignal("AbsoluteSize"):Connect(resizeNametags)

local UserInputService = game:GetService("UserInputService")

UserInputService.WindowFocused:Connect(resizeNametags)
UserInputService.WindowFocusReleased:Connect(resizeNametags)

local function loadNametags() -- line: 250
    -- upvalues: ItemInfo (copy), Nametags (copy), Nametag (copy), Nametags2 (copy), Nametags3 (copy), Template (copy), resizeNametags (copy), loadDescription (copy)
    local v23 = false

    for _, child in ipairs(Nametags:GetChildren()) do
        if child:IsA("IntValue") then
            local v24 = Nametags3:FindFirstChild(child.Name)

            if child.Value < 1 then
                if v24 then
                    v24:Destroy()
                end
            elseif v24 then
                local Value = child.Value

                v24.LayoutOrder = -ItemInfo.Nametags[child.Name].rarity * 1000 + Value

                if table.find(ItemInfo.Crates["Color Crate"].possibilities, child.Name) then
                    v24.LayoutOrder += 500
                end

                if Value > 1 then
                    v24.Amount.Visible = true
                    v24.Amount.Text = "x" .. Value
                else
                    v24.Amount.Visible = false
                end

                if child.Name == Nametag.Value then
                    v24.Equipped.Visible = true
                else
                    v24.Equipped.Visible = false
                end
            else
                local v25 = Nametags2:FindFirstChild(child.Name)

                if v25 then
                    v24 = Template:Clone()
                    v24.Name = child.Name

                    local clone = v25:Clone()

                    clone.Parent = v24
                    clone.AnchorPoint = Vector2.new(0.5, 0.5)

                    local UISizeConstraint = clone:FindFirstChild("UISizeConstraint")

                    if UISizeConstraint then
                        UISizeConstraint:Destroy()
                    end

                    for _, child in ipairs(clone:GetChildren()) do
                        if child.Name == "UpperText" then
                            child.Size = UDim2.new(child.Size.X.Scale, 0, 1, 0)
                            child.TextWrapped = false
                            child.TextYAlignment = Enum.TextYAlignment.Center
                        end

                        if child.Name == "Background" then
                            child.Size = UDim2.new(1, 0, 1, 0)
                            child.SizeConstraint = Enum.SizeConstraint.RelativeXY
                        end
                    end

                    clone.Parent = v24
                    v24.Parent = Nametags3

                    local Activated = v24.Activated

                    v23 = true
                    Activated:Connect(function() -- line: 288
                        -- upvalues: child (copy), loadDescription (copy)
                        loadDescription(child.Name)
                    end)

                    local Value = child.Value

                    v24.LayoutOrder = -ItemInfo.Nametags[child.Name].rarity * 1000 + Value

                    if table.find(ItemInfo.Crates["Color Crate"].possibilities, child.Name) then
                        v24.LayoutOrder += 500
                    end

                    if Value > 1 then
                        v24.Amount.Visible = true
                        v24.Amount.Text = "x" .. Value
                    else
                        v24.Amount.Visible = false
                    end

                    if child.Name == Nametag.Value then
                        v24.Equipped.Visible = true
                    else
                        v24.Equipped.Visible = false
                    end
                end
            end
        end
    end

    if v23 then
        resizeNametags()
    end
end

local function loadCrates() -- line: 316
    -- upvalues: ItemInfo (copy), CrateList (copy), Template2 (copy), loadCrateDescription (copy)
    for v26, v27 in pairs(ItemInfo.Crates) do
        local clone = Template2:Clone()

        clone.LayoutOrder = v27.price
        clone.BuyFrame.Price.Text = v27.price
        clone.Title.Text = v26
        clone.Name = v26
        clone.Parent = CrateList

        local ViewportFrame = clone.ViewportFrame
        local v28 = ItemInfo.Crates[v26]
        local v29 = v28.decal or ""
        local v30 = v28.color or Color3.new(1, 1, 1)

        ViewportFrame.Top.Bottom.Decal.Texture = v29
        ViewportFrame.Top.Decal.Texture = v29
        ViewportFrame.Top.Color = v30
        ViewportFrame.Top.Bottom.Color = v30
        clone.Activated:Connect(function() -- line: 335
            -- upvalues: v26 (copy), loadCrateDescription (copy)
            loadCrateDescription(v26)
        end)
    end
end

script.Parent.Done.Activated:Connect(function() -- line: 341
    script.Parent.Visible = false
end)
Description.Container.EquipButton.Activated:Connect(function() -- line: 345
    -- upvalues: SetNametag (copy), Nametag (copy), v5 (ref)
    local v32 = v5

    v32 = v32 and v5 == Nametag.Value

    if not v32 then
        SetNametag:FireServer(v5)
    else
        SetNametag:FireServer("Default")
    end
end)

local BuyCrate = game.ReplicatedStorage.Events.BuyCrate
local v35 = true

Description2.Container.OpenButton.Activated:Connect(function() -- line: 357
    -- upvalues: ItemInfo (copy), v6 (ref), Error (copy), Tokens2 (copy), BuyCrate (copy), v35 (ref)
    if not v35 or script.Parent.Parent.CrateScreen.Visible then
        return
    end

    if v6 then
        if Tokens2.Value < ItemInfo.Crates[v6].price then
            Error:Play()
        end

        print("sending event!")
        BuyCrate:FireServer(v6)
    end

    v35 = false
    wait(5)
    v35 = true
end)
loadNametags()
loadDescription()
loadCrates()
resizeNametags()
openTab("Inventory")

local Value = Tokens2.Value

Tokens.Text = commaValue(Value)
script.Parent:GetPropertyChangedSignal("Visible"):Connect(function() -- line: 380
    -- upvalues: resizeNametags (copy), loadDescription (copy)
    if script.Parent.Visible then
        wait()
        resizeNametags()
        loadDescription()
    end
end)
Nametag.Changed:Connect(function(_) -- line: 388
    -- upvalues: loadNametags (copy)
    updateEquipped()
    loadNametags()
end)

local function watchNametagVal(p11) -- line: 394
    -- upvalues: loadNametags (copy)
    p11.Changed:Connect(loadNametags)
end

Nametags.ChildAdded:Connect(function(p12) -- line: 398
    -- upvalues: loadNametags (copy)
    if not p12:IsA("IntValue") then
        return
    end

    p12.Changed:Connect(loadNametags)
    loadNametags()
end)

for _, child in ipairs(Nametags:GetChildren()) do
    child.Changed:Connect(loadNametags)
end

if game:GetService("PolicyService"):GetPolicyInfoForPlayerAsync(LocalPlayer).ArePaidRandomItemsRestricted then
    script.Parent.Tabs.Crates.Visible = false
    openTab("Inventory")
end
