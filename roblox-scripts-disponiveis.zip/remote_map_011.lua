-- https://lua.expert

local LocalPlayer = game.Players.LocalPlayer
local AdminEvent = game.ReplicatedStorage.Events.AdminEvent
local _ = LocalPlayer:WaitForChild("AdminLevel").Value
local TextBox = script.Parent.Frame.Message.TextBox

script.Parent.Frame.Done.TextButton.Activated:Connect(function() -- line: 7
    script.Parent.Visible = false
end)
script.Parent.Frame.Give.TextButton.Activated:Connect(function() -- line: 11
    -- upvalues: AdminEvent (copy), TextBox (copy)
    AdminEvent:FireServer("Announcement", TextBox.Text)
end)
