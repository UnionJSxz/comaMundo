-- https://lua.expert

local _ = game.Players.LocalPlayer
local ServerSettings = game.ReplicatedStorage:WaitForChild("ServerSettings")
local SetServerSettings = game.ReplicatedStorage.Events.SetServerSettings
local TextButton = script.Parent.Frame.Pause.TextButton
local TextButton2 = script.Parent.Frame.Skip.TextButton
local Done = script.Parent.Done
local v1 = Color3.fromRGB(209, 0, 0)
local v2 = Color3.fromRGB(82, 176, 77)
local v3 = Color3.fromRGB(95, 200, 88)
local v4 = Color3.fromRGB(208, 68, 72)

function turnOff(p1) -- line: 16
    -- upvalues: v1 (copy), v4 (copy)
    p1.BackgroundColor3 = v1
    p1.UIStroke.Color = v4
    p1.Text = "PAUSED"
end

function turnOn(p2) -- line: 22
    -- upvalues: v2 (copy), v3 (copy)
    p2.BackgroundColor3 = v2
    p2.UIStroke.Color = v3
    p2.Text = "UNPAUSED"
end

function updateButtons() -- line: 28
    -- upvalues: ServerSettings (copy), TextButton (copy)
    if ServerSettings.Paused.Value then
        turnOff(TextButton)
    else
        turnOn(TextButton)
    end
end

TextButton.Activated:Connect(function() -- line: 36
    -- upvalues: ServerSettings (copy), SetServerSettings (copy)
    SetServerSettings:FireServer({
        Paused = not ServerSettings.Paused.Value
    })
end)
TextButton2.Activated:Connect(function() -- line: 40
    -- upvalues: SetServerSettings (copy)
    SetServerSettings:FireServer({
        MapTime = 5
    })
end)
ServerSettings.Paused.Changed:Connect(updateButtons)
Done.Activated:Connect(function() -- line: 46
    script.Parent.Visible = false
end)
updateButtons()
