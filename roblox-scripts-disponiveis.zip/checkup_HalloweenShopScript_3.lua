-- https://lua.expert

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ItemInfo = require(game.ReplicatedStorage.ItemInfo)
local LocalPlayer = Players.LocalPlayer
local HalloweenEvent = LocalPlayer:WaitForChild("HalloweenEvent")
local SoundModule = require(game.ReplicatedStorage.SoundModule)
local Sell = SoundModule.newSound(script, "Sell")
local Error = SoundModule.newSound(script, "Error")

function commaValue(p1) -- line: 13
    repeat
        local v2

        p1, v2 = string.gsub(p1, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v2 == 0

    return p1
end

local n1 = 0

function setCubes(p2) -- line: 26
    -- upvalues: Sell (copy), n1 (ref)
    if p2 < n1 then
        Sell:Play()
    end

    n1 = p2
    script.Parent.CubeFrame.CounterFrame.Cubes.Text = commaValue(p2)
end

HalloweenEvent.Candy.Changed:Connect(setCubes)
setCubes(HalloweenEvent.Candy.Value)

local Offers = script.Parent:WaitForChild("ShopFrames"):WaitForChild("Offers")
local Template = Offers:WaitForChild("Template")

Template.Parent = nil

for v3, v4 in pairs(ItemInfo.EventOffers) do
    local clone = Template:Clone()

    clone.Title.Text = string.upper(v3)
    clone.BuyFrame.Price.Text = v4.Price

    if v4.Icon then
        clone.ItemImage.Image = v4.Icon
        clone.ItemImage.Size = UDim2.fromScale(1, 0.8)
    else
        clone.ItemImage.Position = UDim2.fromScale(0.5, 0.65)
        clone.ItemImage.Image = Players:GetUserThumbnailAsync(game.Players.LocalPlayer.UserId, Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size420x420)

        local clone2 = game.ReplicatedStorage:WaitForChild("Nametags"):WaitForChild("Haunted"):Clone()

        clone2.Parent = clone.ItemImage
        clone2.Size = UDim2.new(10, 0, 0.5, 0)
        clone2.Position = UDim2.new(0.5, 0, 0.08, 0)
        clone2:WaitForChild("UpperText").Text = LocalPlayer.DisplayName
        task.delay(1, function() -- line: 60
            -- upvalues: clone2 (copy)
            clone2.UpperText.Size = UDim2.new(4.4, 0, 1, 0)
        end)
    end

    if v4.Amount then
        clone.Amount.Visible = true
        clone.Amount.Text = "x" .. v4.Amount
    end

    clone.Activated:Connect(function() -- line: 69
        -- upvalues: ReplicatedStorage (copy), Error (copy), n1 (ref), v3 (copy), v4 (copy)
        if n1 < v4.Price then
            Error:Play()
        else
            ReplicatedStorage.Events.HalloweenEvent:FireServer(v3)
        end
    end)
    clone.Parent = Offers
end

script.Parent.Done.Activated:Connect(function() -- line: 79
    script.Parent.Visible = false
end)
