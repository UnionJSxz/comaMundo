# Inventário dos arquivos de cliente

Os 25 arquivos Lua foram copiados de `Downloads/workspace`; as cópias preservam os nomes e o conteúdo. Seus horários indicam exportação anterior, em 15/11/2026. A origem exata e a correspondência integral com a sessão atual não foram verificadas. Os cabeçalhos e a estrutura sugerem saída de descompilação, sujeita a perda de nomes e estrutura.

## Arquivos e funções inferidas do conteúdo

- `remote_map_001.lua`: contador de cubos e animações da interface; eventos `SetCubes` e `CubesAdded`.
- `remote_map_002.lua`: tamanho, barra de progresso, crescimento e venda.
- `remote_map_003.lua` a `remote_map_005.lua`: elementos associados a compras; verificar o contexto de cada controle.
- `remote_map_006.lua`: interface de melhorias e eventos; usa `PurchaseEvent`, `SummonEvent`, `Tokens` e `EventList`.
- `remote_map_007.lua` e `remote_map_008.lua`: preferências e identificação visual (`SetPreferences`, `SetNametag`).
- `remote_map_009.lua` a `remote_map_011.lua`: administração e configuração do servidor.
- `remote_map_012.lua`: caixas e identificação visual (`CrateOpen`, `SetNametag`).
- `remote_map_013.lua`: recompensas e roleta (`RewardEvent`, `SpinEvent`).
- `remote_map_014.lua`: solicitação de teleporte (`RequestTeleport`).
- `remote_map_015.lua`: votação de mapas (`MapVote`).
- `remote_map_016.lua`: componentes de interface e compras; finalidade completa requer inspeção contextual.
- `remote_map_017.lua`: loja e interface de compras, melhorias, eventos e caixas.
- `remote_map_018.lua`: recompensas e resgate de identificação ou tamanho (`ClaimNametag`, `ClaimMaxSize`).
- `remote_map_019.lua` a `remote_map_022.lua`: administração e compras; alguns duplicam arquivos anteriores.
- `checkup_*.lua`: cópias de scripts associados a administração e à loja de Halloween.

## Duplicatas exatas

- `checkup_AdminButtons_1.lua` = `remote_map_009.lua`.
- `checkup_PublicAdmin_2.lua` = `remote_map_019.lua`.
- `checkup_HalloweenShopScript_3.lua` = `remote_map_022.lua`.
- `remote_map_005.lua` = `remote_map_020.lua`.

São 21 conteúdos distintos por comparação SHA-256. Os nomes de eventos são referências encontradas nos arquivos, não demonstram a implementação ou o comportamento do servidor. As interfaces, módulos, recursos visuais e outros scripts citados podem estar ausentes. A listagem completa de scripts acessíveis na sessão ainda não foi obtida.
