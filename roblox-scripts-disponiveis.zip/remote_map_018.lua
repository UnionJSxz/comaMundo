-- https://lua.expert

local Parent = script.Parent

Color3.new(0, 1, 0)

local v1 = Color3.new(0.4, 0.4, 0.4)
local v2 = Color3.new(0.8, 0.8, 0.8)

Color3.new(1, 0.717647, 0.223529)
Color3.fromRGB(209, 0, 0)

local v3 = Color3.fromRGB(82, 176, 77)
local v4 = Color3.fromRGB(95, 200, 88)

Color3.fromRGB(208, 68, 72)

local LocalPlayer = game.Players.LocalPlayer

require(game.ReplicatedStorage.ItemInfo)

local SmileysPromo = require(game.ReplicatedStorage.SmileysPromo)
local Stats = LocalPlayer:WaitForChild("Stats")
local SmileysPromo2 = LocalPlayer:WaitForChild("SmileysPromo")
local BadgeService = game:GetService("BadgeService")

function turnOff(p1, _) -- line: 26
    -- upvalues: v1 (copy), v2 (copy)
    p1.BackgroundColor3 = v1
    p1.UIStroke.Color = v2
end

function turnOn(p3, _) -- line: 31
    -- upvalues: v3 (copy), v4 (copy)
    p3.BackgroundColor3 = v3
    p3.UIStroke.Color = v4
end

function commaValue(p5) -- line: 36
    repeat
        local v6

        p5, v6 = string.gsub(p5, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v6 == 0

    return p5
end

function adjustBar(p6, p7) -- line: 48
    local v7 = 1 / p7

    p6.Size = UDim2.new(p7, 0, 1, 0)
    p6.Bar.Size = UDim2.new(v7, 0, 1, 0)
end

local v8 = false

function timeValue(p8, p9) -- line: 57
    if not p8 then
        return
    end

    local v10 = math.floor(p8 / 3600)

    if v10 < 10 and p9 then
        v10 = "0" .. v10
    end

    local v12 = math.floor(p8 % 3600 / 60)
    local v13, v14

    if v12 < 10 then
        if p9 then
            v14 = false
        elseif tonumber(v10) == 0 then
            v13 = v12
            v14 = true
        else
            v14 = false
        end
    else
        v13 = v12
        v14 = true
    end

    if not v14 then
        v13 = "0" .. v12
    end

    local v16 = math.floor(p8 % 60)
    local v17, v18

    if v16 < 10 then
        if p9 then
            v18 = false
        elseif tonumber(v13) == 0 then
            v17 = v16
            v18 = true
        else
            v18 = false
        end
    else
        v17 = v16
        v18 = true
    end

    if not v18 then
        v17 = "0" .. v16
    end

    if p9 or tonumber(v10) ~= 0 then
        return v10 .. ":" .. v13 .. ":" .. v17
    end

    if tonumber(v13) == 0 then
        return v17 .. "s"
    end

    return v13 .. ":" .. v17
end

local v19 = "Today's Quest - resets in ("
local v20

function updateTasks() -- line: 79
    -- upvalues: Parent (copy), LocalPlayer (copy), SmileysPromo (copy), BadgeService (copy), v19 (ref), v20 (ref)
    local v21 = (SmileysPromo.GetTodaysNumber() + 1) * 86400 - os.time()

    script.Parent.Tasks.TimeLeft.Text = v19 .. timeValue(v21) .. "):"

    local v22 = SmileysPromo.GetTodaysBadgeId()

    if v20 == v22 then
        return
    end

    v20 = v22

    if not (v20 and BadgeService:UserHasBadgeAsync(LocalPlayer.UserId, v20)) then
        adjustBar(Parent.Tasks.Task.Progress.ProgressBar, 0)
        Parent.Tasks.Task.Progress.ProgressText.Text = "0/1"
    else
        v19 = "Quest complete! - new quest in ("
        adjustBar(Parent.Tasks.Task.Progress.ProgressBar, 1)
        Parent.Tasks.Task.Progress.ProgressText.Text = "1/1"
    end
end

local Error = require(game.ReplicatedStorage.SoundModule).newSound(script, "Error")
local n1 = 0

Parent.Claim.Activated:Connect(function() -- line: 104
    -- upvalues: Parent (copy), LocalPlayer (copy), BadgeService (copy), Error (copy), n1 (ref)
    if BadgeService:UserHasBadgeAsync(LocalPlayer.UserId, 3169993960180710) then
        game.ReplicatedStorage.Events.ClaimNametag:FireServer()
    else
        Error:Play()
        n1 += 1

        local v23 = n1

        Parent.Error.Text = "Reach rank 5 in Smileys to claim this nametag!"
        Parent.Error.Visible = true
        wait(3)

        if v23 == n1 then
            Parent.Error.Visible = false
        end
    end
end)
Parent.Done.Activated:Connect(function() -- line: 119
    script.Parent.Visible = false
end)
game:GetService("TweenService")
TweenInfo.new(5, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1, false, 0)
TweenInfo.new(2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, 0)

local UserThumbnailAsync = game.Players:GetUserThumbnailAsync(game.Players.LocalPlayer.UserId, Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size420x420)

script.Parent.RewardWindow.ImageLabel.Image = UserThumbnailAsync

local clone = game.ReplicatedStorage:WaitForChild("Nametags"):WaitForChild("Smileys"):Clone()

clone.Parent = script.Parent.RewardWindow.ImageLabel
clone.Size = UDim2.new(1, 0, 0.3, 0)
clone.Position = UDim2.new(0.5, 0, 0.08, 0)
clone:WaitForChild("UpperText").Text = game.Players.LocalPlayer.DisplayName
clone.UpperText.Size = UDim2.new(1, 0, 1, 0)

local TweenService = game:GetService("TweenService")
local v24 = TweenInfo.new(30, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, false, 0)

TweenService:Create(script.Parent.RewardWindow:WaitForChild("Glow"), v24, {
    Rotation = 359
}):Play()

local Nametags = LocalPlayer:WaitForChild("Nametags")

if Nametags:FindFirstChild("Smileys") then
    turnOff(Parent.Claim)
    Parent.Claim.Text = "Claimed!"
    Parent.Secret.Text = "You got a bonus reward of 20 tokens!"
else
    Nametags.ChildAdded:Connect(function(_) -- line: 157
        -- upvalues: Parent (copy), v8 (ref), Nametags (copy)
        if not Nametags:FindFirstChild("Smileys") then
            return
        end

        v8 = true
        turnOff(Parent.Claim)
        Parent.Claim.Text = "Claimed!"
        Parent.Secret.Text = "You got a bonus reward of 20 tokens!"
    end)
end

local n2 = 0

function updateFreeMax() -- line: 170
    -- upvalues: Parent (copy), v1 (copy), v3 (copy), SmileysPromo2 (copy), n2 (ref)
    n2 = SmileysPromo2.FreeMax.Value

    if n2 < 1 then
        Parent.Tasks.Claim.BackgroundColor3 = v1
        Parent.Tasks.Claim.UIStroke.Color = v1
        Parent.Tasks.Claim.TextLabel.Visible = false
    else
        Parent.Tasks.Claim.BackgroundColor3 = v3
        Parent.Tasks.Claim.UIStroke.Color = v3
        Parent.Tasks.Claim.TextLabel.Visible = true
        Parent.Tasks.Claim.TextLabel.Text = n2 .. " REMAINING"
    end
end

SmileysPromo2:WaitForChild("FreeMax").Changed:Connect(updateFreeMax)
updateFreeMax()

if Stats:WaitForChild("LogInTimes").Value > 2 and SmileysPromo2:WaitForChild("Viewed").Value < 1 then
    Parent.Visible = true
end

Parent.Tasks.Claim.Activated:Connect(function() -- line: 191
    -- upvalues: Parent (copy), Error (copy), n1 (ref), n2 (ref)
    if n2 > 0 then
        game.ReplicatedStorage.Events.ClaimMaxSize:FireServer()
    else
        Error:Play()
        n1 += 1

        local v25 = n1

        Parent.Error.Text = "Complete a daily quest to get a free max size!"
        Parent.Error.Visible = true
        wait(3)

        if v25 == n1 then
            Parent.Error.Visible = false
        end
    end
end)

while true do
    local function v26() -- line: 208
        updateTasks()
    end

    pcall(v26)
    wait(1)
end
