-- https://lua.expert

local LocalPlayer = game.Players.LocalPlayer
local Preferences = LocalPlayer:WaitForChild("Preferences")
local Nametags = LocalPlayer:WaitForChild("Nametags")
local Nametag = LocalPlayer:WaitForChild("Nametag")
local SetPreferences, SetNametag = game.ReplicatedStorage.Events.SetPreferences, game.ReplicatedStorage.Events.SetNametag
local TextButton = script.Parent.Frame.ShowNametag.TextButton

require(game.ReplicatedStorage.ItemInfo)

local v1 = Color3.fromRGB(209, 0, 0)
local v2 = Color3.fromRGB(82, 176, 77)
local v3 = Color3.fromRGB(95, 200, 88)
local v4 = Color3.fromRGB(208, 68, 72)
local v5 = Color3.new(0.4, 0.4, 0.4)

Color3.new(0.8, 0.8, 0.8)

function turnOff(p1, p2) -- line: 21
    -- upvalues: v1 (copy), v4 (copy)
    p1.BackgroundColor3 = v1
    p1.UIStroke.Color = v4

    if not p2 then
        p1.Text = "OFF"
    end
end

function turnGrey(p3, _) -- line: 29
    -- upvalues: v5 (copy)
    p3.BackgroundColor3 = v5
    p3.UIStroke.Color = v5
end

function turnOn(p5, p6) -- line: 34
    -- upvalues: v2 (copy), v3 (copy)
    p5.BackgroundColor3 = v2
    p5.UIStroke.Color = v3

    if not p6 then
        p5.Text = "ON"
    end
end

function updateButtons() -- line: 43
    -- upvalues: Preferences (copy), Nametag (copy), TextButton (copy)
    if Preferences.ShowNametag.Value then
        turnOn(TextButton)
    else
        turnOff(TextButton)
    end

    for _, child in ipairs(script.Parent.Frame.Nametags:GetChildren()) do
        if child:IsA("TextButton") then
            if child.Name == Nametag.Value then
                turnOn(child, true)
            else
                turnGrey(child, true)
            end
        end
    end
end

TextButton.Activated:Connect(function() -- line: 59
    -- upvalues: Preferences (copy), SetPreferences (copy)
    SetPreferences:FireServer({
        ShowNametag = not Preferences.ShowNametag.Value
    })
end)
Preferences.ShowNametag.Changed:Connect(updateButtons)
Nametag.Changed:Connect(updateButtons)

local Template = script.Parent.Frame.Nametags.Template

Template.Parent = nil

local function addTemplate(p7) -- line: 70
    -- upvalues: SetNametag (copy), Template (copy)
    if not p7 then
        return
    end

    local clone = Template:Clone()

    clone.Name = p7
    clone.Text = string.upper(p7)
    clone.Parent = script.Parent.Frame.Nametags
    clone.Activated:Connect(function() -- line: 77
        -- upvalues: p7 (copy), SetNametag (copy)
        SetNametag:FireServer(p7)
    end)
end

addTemplate("Default")
script.Parent.Frame.Nametags.Default.LayoutOrder = -100

for _, child in ipairs(Nametags:GetChildren()) do
    addTemplate(child.Name)
end

Nametags.ChildAdded:Connect(function(p8) -- line: 91
    -- upvalues: addTemplate (copy)
    addTemplate(p8.Name)
    updateButtons()
end)
updateButtons()
