# Mapa preliminar de eventos e dependências

Este mapa foi inferido por leitura estática dos arquivos Lua já exportados. Não é uma exportação da hierarquia em execução; nomes, localização, tipos, argumentos e disponibilidade devem ser confirmados no cliente atual. `FireServer` e `OnClientEvent` indicam uso compatível com RemoteEvent, mas não descrevem validações ou implementação no servidor.

| Referência observada | Uso visível | Evidência |
| --- | --- | --- |
| `ReplicatedStorage.Events.SetCubes` | Envio sem argumentos e recebimento de um valor | `remote_map_001.lua` |
| `ReplicatedStorage.Events.CubesAdded` | Recebimento com dois argumentos | `remote_map_001.lua` |
| `ReplicatedStorage.Events.PurchaseEvent` | Solicitações relacionadas a compras | `remote_map_003.lua`, `004`, `005`, `006` |
| `ReplicatedStorage.Events.SetPreferences` | Envio de tabelas de preferências | `remote_map_007.lua`, `008` |
| `ReplicatedStorage.Events.SetNametag` | Envio de seleção de identificação | `remote_map_008.lua`, `012`, `017` |
| `ReplicatedStorage.Events.AdminEvent` | Solicitação de interface e anúncios | `remote_map_009.lua`, `011` |
| `ReplicatedStorage.Events.PublicAdmin` | Solicitações administrativas | `remote_map_019.lua` |
| `ReplicatedStorage.Events.SetServerSettings` | Referenciado em configurações | `remote_map_010.lua` |
| `ReplicatedStorage.Events.CrateOpen` | Recebimento com dois argumentos | `remote_map_012.lua` |
| `ReplicatedStorage.Events.RewardEvent` | Solicitação e recebimento | `remote_map_013.lua` |
| `ReplicatedStorage.Events.SpinEvent` | Solicitação e recebimento | `remote_map_013.lua` |
| `ReplicatedStorage.Events.RequestTeleport` | Solicitações com destinos textuais | `remote_map_014.lua` |
| `ReplicatedStorage.Events.MapVote` | Recebimento e envio de escolha e posição | `remote_map_015.lua` |
| `ReplicatedStorage.Events.BuyCrate` | Solicitação de compra de caixa | `remote_map_017.lua` |
| `ReplicatedStorage.Events.ClaimNametag`, `ClaimMaxSize` | Solicitações de recompensas | `remote_map_018.lua` |
| `ReplicatedStorage.Events.HalloweenEvent` | Solicitação relacionada à loja sazonal | `remote_map_022.lua` |
| `ReplicatedStorage.Events.SummonEvent` | Referenciado em loja/eventos | `remote_map_006.lua`, `017` |
| `Character.Events.Eat`, `Sell` | Recebimento de consumo e solicitação de venda; o objeto `v1` deve ser confirmado | `remote_map_002.lua` |

Outras dependências observadas incluem `ReplicatedStorage.Nametags`, `ReplicatedStorage.ServerSettings`, `SoundModule`, dados do jogador como `Upgrades`, `Preferences`, `Stats`, `Nametags` e `Tokens`, além de elementos de interface acessados por `script.Parent`. Os valores exatos, árvores e recursos dessas dependências não estão incluídos neste pacote.
