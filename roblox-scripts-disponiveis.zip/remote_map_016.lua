-- https://lua.expert

local LocalPlayer = game.Players.LocalPlayer
local MarketplaceService = game:GetService("MarketplaceService")
local ItemInfo = require(game.ReplicatedStorage:WaitForChild("ItemInfo"))
local Stats = LocalPlayer:WaitForChild("Stats")
local Playtime = Stats:WaitForChild("Playtime")
local StarterPackPurchased = Stats:WaitForChild("StarterPackPurchased")
local Value = game.ReplicatedStorage:WaitForChild("ServerSettings"):WaitForChild("StarterPackTime").Value
local StarterPackButton = script.Parent.Parent.StarterPackButton
local connection, connection2
local PurchaseEvent = game.ReplicatedStorage:WaitForChild("Events"):WaitForChild("PurchaseEvent")
local TweenService = game:GetService("TweenService")
local v1 = TweenInfo.new(15, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, false, 0)
local v2, v3

local function endPromo() -- line: 30
    -- upvalues: StarterPackButton (copy), connection (ref), connection2 (ref), v2 (ref), v3 (ref)
    if connection then
        connection:Disconnect()
        connection = nil
    end

    if connection2 then
        connection2:Disconnect()
        connection2 = nil
    end

    StarterPackButton.Visible = false
    script.Parent.Visible = false

    if v2 then
        v2:Cancel()
        v2 = nil
    end

    if v3 then
        v3:Cancel()
        v3 = nil
    end
end

local function updateTimers(p1) -- line: 51
    -- upvalues: Value (copy), StarterPackButton (copy)
    local v4 = p1 / (Value - 180) * 360
    local Mask = StarterPackButton.CircularIndicator:FindFirstChild("Right"):FindFirstChild("Mask")
    local Mask2 = StarterPackButton.CircularIndicator:FindFirstChild("Left"):FindFirstChild("Mask")
    local v6 = math.clamp(v4 - 180, -180, 0)
    local Rotation = Mask2.Rotation
    local v7 = false

    if v4 > 180 then
        Rotation = math.clamp(v4 - 360, -180, 0)
        v7 = true
    end

    Mask.Rotation = v6
    Mask2.Visible = v7
    Mask2.Rotation = Rotation

    local v10 = math.floor(p1 % 86400 / 3600)

    if v10 < 10 then
        local _ = "0" .. v10
    end

    local v12 = math.floor(p1 % 3600 / 60)

    if v12 < 10 then
        v12 = "0" .. v12
    end

    local v14 = math.floor(p1 % 60)

    if v14 < 10 then
        v14 = "0" .. v14
    end

    local v15 = v12 .. ":" .. v14

    StarterPackButton.Timer.Text = v15
    script.Parent.TimeLeft.Text = "OFFER ENDS IN " .. v15

    if p1 < 60 then
        StarterPackButton.Timer.TextColor3 = Color3.new(1, 0, 0)
        script.Parent.TimeLeft.TextColor3 = Color3.new(1, 0, 0)
    end
end

function formatImage(p2) -- line: 93
    p2.ImageLabel.Position = UDim2.new(0.45, -p2.TextBounds.X / 2, 0.5, 0)

    local v16 = p2.Parent.AbsolutePosition.X + p2.Parent.AbsoluteSize.X

    if p2.AbsolutePosition.X + p2.AbsoluteSize.X - v16 > 0 then
    end
end

function commaValue(p3) -- line: 104
    repeat
        local v18

        p3, v18 = string.gsub(p3, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v18 == 0

    return p3
end

local Sell = require(game.ReplicatedStorage.SoundModule).newSound(script, "Sell")

local function init() -- line: 119
    -- upvalues: MarketplaceService (copy), ItemInfo (copy), Playtime (copy), StarterPackPurchased (copy), Value (copy), StarterPackButton (copy), connection (ref), connection2 (ref), PurchaseEvent (copy), TweenService (copy), v1 (copy), v2 (ref), v3 (ref), endPromo (copy), updateTimers (copy), Sell (copy)
    connection = Playtime.Changed:Connect(function(p4) -- line: 122
        -- upvalues: StarterPackPurchased (copy), Value (copy), StarterPackButton (copy), endPromo (copy), updateTimers (copy)
        if Value < p4 then
            endPromo()
        else
            updateTimers(Value - p4)

            if p4 == 180 then
                StarterPackButton.Visible = true
                script.Parent.Visible = true
            elseif p4 > 180 and not StarterPackButton.Visible and StarterPackPurchased.Value <= 0 then
                StarterPackButton.Visible = true
            end
        end
    end)
    connection2 = StarterPackPurchased.Changed:Connect(function(p5) -- line: 136
        -- upvalues: endPromo (copy), Sell (copy)
        if p5 > 0 then
            Sell:Play()
            endPromo()
        end
    end)

    local v19

    local function v20() -- line: 144
        -- upvalues: v19 (ref), MarketplaceService (copy), ItemInfo (copy)
        v19 = MarketplaceService:GetProductInfo(ItemInfo.DevProducts["Starter Pack"], Enum.InfoType.Product)
    end

    pcall(v20)

    if v19 and v19.PriceInRobux then
        script.Parent.BuyText.Button.Text = "" .. v19.PriceInRobux
    end

    script.Parent.Money.Text = commaValue(ItemInfo.Bundles["Starter Pack"].Cubes)
    script.Parent.Tokens.Text = commaValue(ItemInfo.Bundles["Starter Pack"].Tokens)
    formatImage(script.Parent.Money)
    formatImage(script.Parent.Tokens)
    script.Parent.TextButton.Activated:Connect(function() -- line: 155
        -- upvalues: PurchaseEvent (copy)
        PurchaseEvent:FireServer("Starter Pack")
    end)
    script.Parent.BuyText.Button.Activated:Connect(function() -- line: 158
        -- upvalues: PurchaseEvent (copy)
        PurchaseEvent:FireServer("Starter Pack")
    end)
    StarterPackButton.Button.Activated:Connect(function() -- line: 162
        script.Parent.Visible = true
    end)
    v2 = TweenService:Create(StarterPackButton.GlowFX.Glow, v1, {
        Rotation = 359
    })
    v3 = TweenService:Create(script.Parent.ImageFrame.Glow, v1, {
        Rotation = 359
    })
    v2:Play()
    v3:Play()
end

if not (Playtime.Value < Value and StarterPackPurchased.Value <= 0) then
    endPromo()
else
    init()
end

script.Parent.Done.Activated:Connect(function() -- line: 177
    script.Parent.Visible = false
end)

function gamepadButtons(p6) -- line: 181
    if p6 == Enum.UserInputType.Gamepad1 then
        script.Parent.BuyText.Button.ImageLabel.Image = game.UserInputService:GetImageForKeyCode(Enum.KeyCode.ButtonX)
    else
        script.Parent.BuyText.Button.ImageLabel.Image = ""
    end
end

game.UserInputService.InputBegan:Connect(function(p7) -- line: 190
    -- upvalues: PurchaseEvent (copy)
    gamepadButtons(p7.UserInputType)

    if script.Parent.Visible then
        if p7.KeyCode == Enum.KeyCode.ButtonB then
            script.Parent.Visible = false
        end

        if p7.KeyCode == Enum.KeyCode.ButtonX then
            wait(0.1)

            if script.Parent.Visible then
                PurchaseEvent:FireServer("Starter Pack")
            end
        end
    end
end)
