-- https://lua.expert

if game.PlaceId == 16480898254 then
    script.Parent.Frame.TextButton.Activated:Connect(function() -- line: 3
        game.ReplicatedStorage.Events.RequestTeleport:FireServer("Mega")
    end)
else
    script.Parent.TextLabel.Text = "NORMAL MAPS"
    script.Parent.Frame.Frame.Visible = false
    script.Parent.Frame.Title.Visible = true
    script.Parent.Parent.SideButtons.MegaMaps.TopLabel.Text = "NORMAL"
    script.Parent.Frame.TextButton.Activated:Connect(function() -- line: 11
        game.ReplicatedStorage.Events.RequestTeleport:FireServer("Normal")
    end)
end

script.Parent.Done.Activated:Connect(function() -- line: 17
    script.Parent.Visible = false
end)
