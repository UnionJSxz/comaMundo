-- https://lua.expert

local Parent = script.Parent
local ViewportFrame = script.Parent.ViewportFrame
local CrateOpen = game.ReplicatedStorage.Events.CrateOpen
local ImageLabel = Parent.ImageLabel
local n1 = 0
local ItemInfo = require(game.ReplicatedStorage.ItemInfo)
local Camera = Instance.new("Camera")

ViewportFrame.CurrentCamera = Camera
Camera.Parent = ViewportFrame
Camera.CFrame = CFrame.new(Vector3.new(1.6, 1.5, 1), ViewportFrame.Focus.Position)
game:GetService("ContentProvider"):PreloadAsync({
    ViewportFrame
})

local TweenService = game:GetService("TweenService")
local v1 = TweenInfo.new(0.9, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, 0)
local v2 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
local v3 = TweenInfo.new(10, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 99999999999, false, 0)
local v4 = TweenInfo.new(2, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0)

TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 10, true, 0)
ViewportFrame.Top.Bottom.Orientation = Vector3.new(0, 0, 0)
ViewportFrame.Top.Bottom.Position = Vector3.new(-1, 1, -2.5)
ViewportFrame.Top.Orientation = Vector3.new(0, 0, 0)
ViewportFrame.Top.Position = Vector3.new(-1, 1, -2.5)

local v5 = "Default"
local tween = TweenService:Create(Parent.Roll, v1, {
    Size = UDim2.new(0.8, 0, 0.8, 0)
})
local tween2 = TweenService:Create(ViewportFrame.Top, v1, {
    Orientation = Vector3.new(0, 0, 10),
    Position = Vector3.new(-1, 0.3, -2.5)
})
local tween3 = TweenService:Create(ViewportFrame.Top.Bottom, v1, {
    Orientation = Vector3.new(0, 0, -5),
    Position = Vector3.new(-1, -0.3, -2.5)
})
local tween4 = TweenService:Create(ViewportFrame, v2, {
    Position = UDim2.new(0.5, 0, 0.45, 0)
})

TweenService:Create(ImageLabel, v3, {
    Rotation = 360
}):Play()

local tween5 = TweenService:Create(ImageLabel, v1, {
    Size = UDim2.new(0.6, 0, 0.6, 0)
})
local Template = script.Parent.Roll.Template

Template.Parent = nil

local SoundModule = require(game.ReplicatedStorage.SoundModule)
local Click = SoundModule.newSound(script, "Click")
local Victory = SoundModule.newSound(script, "Victory")

Click.PlayOnRemove = true

local t1 = {
    {
        "Common",
        Color3.new(1, 1, 1)
    },
    {
        "Uncommon",
        Color3.new(0.470588, 1, 0.0666667)
    },
    {
        "RARE",
        Color3.new(1, 0, 0)
    },
    {
        "EVENT",
        Color3.new(1, 0.85098, 0)
    },
    {
        "LEGENDARY",
        Color3.new(0, 0.898039, 1)
    },
    {
        "MYTHIC",
        Color3.new(0.831373, 0, 1)
    }
}

CrateOpen.OnClientEvent:Connect(function(p1, p2) -- line: 94
    -- upvalues: Parent (copy), ViewportFrame (copy), ImageLabel (copy), n1 (ref), ItemInfo (copy), TweenService (copy), v4 (copy), v5 (ref), tween (copy), tween2 (copy), tween3 (copy), tween4 (copy), tween5 (copy), Template (copy), Click (copy), Victory (copy), t1 (copy)
    v5 = p1
    ViewportFrame.Top.Color = Color3.new(0.424, 0.345, 0.264)
    ViewportFrame.Top.Bottom.Color = Color3.new(0.424, 0.345, 0.264)
    Parent.Roll.Visible = false
    Parent.Done.Visible = false
    Parent.Equip.Visible = false
    ViewportFrame.Position = UDim2.new(0.5, 0, 1.5, 0)
    ViewportFrame.Top.Bottom.Orientation = Vector3.new(0, 0, 0)
    ViewportFrame.Top.Bottom.Position = Vector3.new(-1, 0, -2.5)
    ViewportFrame.Top.Orientation = Vector3.new(0, 0, 0)
    ViewportFrame.Top.Position = Vector3.new(-1, 0, -2.5)
    ImageLabel.Visible = false

    local v6 = ItemInfo.Crates[p2]
    local v7 = v6.decal or ""
    local v8 = v6.color or Color3.new(1, 1, 1)

    ViewportFrame.Top.Bottom.Decal.Texture = v7
    ViewportFrame.Top.Decal.Texture = v7
    ViewportFrame.Top.Color = v8
    ViewportFrame.Top.Bottom.Color = v8
    wait(1)
    Parent.Visible = true
    tween4:Play()
    wait(1)
    tween2:Play()
    tween3:Play()
    ImageLabel.Size = UDim2.new(0.06, 0, 0.06, 0)
    ImageLabel.Visible = true
    tween5:Play()

    local t2 = {}

    game.ReplicatedStorage.Nametags:GetChildren()

    for _, child in ipairs(script.Parent.Roll:GetChildren()) do
        if child:IsA("CanvasGroup") then
            child:Destroy()
        end
    end

    local t3 = {}
    local v9

    for i = 1, 5 do
        v9 = Template:Clone()

        local v10

        while true do
            if not v10 then
                v10 = game.ReplicatedStorage.Nametags:FindFirstChild(v6.possibilities[math.random(1, #v6.possibilities)])
                continue
            end

            if table.find(t3, v10.Name) then
                v10 = game.ReplicatedStorage.Nametags:FindFirstChild(v6.possibilities[math.random(1, #v6.possibilities)])
                continue
            end

            if v10.Name == p1 then
                v10 = game.ReplicatedStorage.Nametags:FindFirstChild(v6.possibilities[math.random(1, #v6.possibilities)])
                continue
            end

            break
        end

        if i == 3 then
            v10 = game.ReplicatedStorage.Nametags[p1]
        end

        table.insert(t3, v10.Name)
        v9.Rarity.Text = t1[ItemInfo.Nametags[v10.Name].rarity][1]
        v9.Rarity.TextColor3 = t1[ItemInfo.Nametags[v10.Name].rarity][2]

        local clone = v10:Clone()

        clone.AnchorPoint = Vector2.new(0.5, 0.5)

        local UISizeConstraint = clone:FindFirstChild("UISizeConstraint")

        if UISizeConstraint then
            UISizeConstraint:Destroy()
        end

        clone.Parent = v9
        v9.Parent = script.Parent.Roll

        for _, child in ipairs(clone:GetChildren()) do
            if child.Name == "UpperText" then
                child.Size = UDim2.new(1, 0, 1, 0)
                child.SizeConstraint = Enum.SizeConstraint.RelativeXY
                child.TextYAlignment = Enum.TextYAlignment.Center
            end

            if child.Name == "Background" then
                local TextBounds = child.Parent.UpperText.TextBounds
                local _ = TextBounds / child.Parent.AbsoluteSize

                child.Size = UDim2.new(TextBounds.X / TextBounds.Y + 0.5, 6, 0.83, 6)
            end
        end

        t2[v9] = i * 0.2 - 0.09999999999999998
    end

    Parent.Roll.Arrow.Visible = true
    Parent.Roll.Visible = true
    Parent.Roll.Size = UDim2.new(0.1, 0, 0.1, 0)
    tween:Play()

    local n2 = 1
    local n3 = 5

    while n3 > 0 do
        local v11 = game["Run Service"].Heartbeat:Wait()

        if v9 and t2[v9] > 0.5 then
            local clone = Click:Clone()

            clone.Parent = script
            v9 = nil
            clone:Destroy()
        end

        n3 -= v11

        local Value = TweenService:GetValue(n3 / 5, Enum.EasingStyle.Cubic, Enum.EasingDirection.In)
        local v12 = (Value - n2) * 5

        n2 = Value

        for v13, v14 in pairs(t2) do
            if v14 < 0.5 and (not v9 or t2[v9] < v14) then
                v9 = v13
            end

            local v15 = v14 - v12

            if v15 > 1 then
                v15 -= 1
            end

            v13.Position = UDim2.new(0.5, 0, v15, 0)
            v13.GroupTransparency = math.sin((v15 + 1) * 3.141592653589793) + 1

            local v18 = -math.sin((v15 + 1) * 3.141592653589793) * 0.15

            v13.Size = UDim2.new(1, 0, v18, 0)
            t2[v13] = v15
        end
    end

    for v19, v20 in pairs(t2) do
        if math.floor(v20 * 10 + 0.5) ~= 5 then
            v19:Destroy()
        end
    end

    Victory:Play()
    Parent.Roll.Arrow.Visible = false

    local v22 = workspace.CurrentCamera.ViewportSize.X / workspace.CurrentCamera.ViewportSize.Y

    for i = 1, 15 do
        local v23 = math.random() * 3 + 4
        local clone = Parent.Coin:Clone()

        clone.Parent = Parent.Effects
        clone.Visible = true

        local v24 = i * 24

        TweenService:Create(clone, v4, {
            ImageTransparency = 1,
            Rotation = math.random(0, 70),
            Position = UDim2.new(0.5 + math.cos(v24) / (v22 * v23), 0, 0.5 + math.sin(v24) / v23, 0)
        }):Play()
    end

    local v25 = n1

    wait(2)
    Parent.Done.Visible = true
    Parent.Equip.Visible = true
    n1 += 1
    wait(10)

    if n1 ~= v25 then
        return
    end

    Parent.Effects:ClearAllChildren()
    Parent.Visible = false
    Parent.Done.Visible = false
    Parent.Equip.Visible = false
end)

local SetNametag = game.ReplicatedStorage.Events.SetNametag

Parent.Equip.MouseButton1Click:Connect(function() -- line: 260
    -- upvalues: Parent (copy), v5 (ref), SetNametag (copy)
    SetNametag:FireServer(v5)
    Parent.Effects:ClearAllChildren()
    Parent.Visible = false
    Parent.Equip.Visible = false
end)
Parent.Done.MouseButton1Click:Connect(function() -- line: 267
    -- upvalues: Parent (copy)
    Parent.Effects:ClearAllChildren()
    Parent.Visible = false
    Parent.Equip.Visible = false
end)
