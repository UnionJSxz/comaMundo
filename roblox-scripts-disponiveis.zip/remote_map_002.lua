-- https://lua.expert

local LocalPlayer = game.Players.LocalPlayer
local Character = LocalPlayer.Character
local v1 = Character

if not Character then
    v1 = LocalPlayer.CharacterAdded:Wait()
end

local Size
local MaxSize = LocalPlayer:WaitForChild("Upgrades"):WaitForChild("MaxSize")
local growthFunction = require(game.ReplicatedStorage.ItemInfo).Upgrades.MaxSize.growthFunction

script.Parent.SplashText.Parent = nil

local v2
local Parent = script.Parent
local ProgressBar = Parent.ProgressBar
local n1 = 0
local SoundModule = require(game.ReplicatedStorage.SoundModule)
local Sell = SoundModule.newSound(script, "Sell")
local Error = SoundModule.newSound(script, "Error")

function commaValue(p1) -- line: 32
    repeat
        local v4

        p1, v4 = string.gsub(p1, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v4 == 0

    return p1
end

function adjustBar(p2, p3) -- line: 44
    -- upvalues: Parent (copy), ProgressBar (copy)
    local v5 = 1 / p3

    p2.Size = UDim2.new(p3, 0, 1, 0)
    p2.Bar.Size = UDim2.new(v5, 0, 1, 0)

    if p3 == 1 then
        script.Parent.ProgressText.Size = UDim2.new(1, 0, 0.7, 0)
        script.Parent.SellText.Visible = true
    else
        script.Parent.ProgressText.Size = UDim2.new(1, 0, 1, 0)
        script.Parent.SellText.Visible = false
        script.Parent.WarningText.Visible = false
    end

    ProgressBar.Bar.ImageLabel.TileSize = UDim2.new(0, Parent.AbsoluteSize.Y / 2, 0, Parent.AbsoluteSize.Y / 2)
end

local function updateMax(p4) -- line: 58
    -- upvalues: growthFunction (copy), v2 (ref), ProgressBar (copy), n1 (ref)
    v2 = growthFunction(p4)
    script.Parent.Size = UDim2.new(math.clamp((p4 - 1) * 0.02, 0, 0.7) + 0.1, 0, 0.1, 0)

    local v9 = math.deg((math.tan(script.Parent.AbsoluteSize.Y / script.Parent.AbsoluteSize.X)))

    script.Parent.UIStroke.UIGradient.Rotation = v9 - 90
    script.Parent.outline.UIStroke.UIGradient.Rotation = v9 - 270
    ProgressBar.Bar.ImageLabel.Frame.UIStroke.UIGradient.Rotation = v9 - 270
    adjustBar(ProgressBar, n1 / v2)
end

updateMax(MaxSize.Value)
MaxSize.Changed:Connect(updateMax)

local v10 = false
local Sell2
local CurrentCamera = workspace.CurrentCamera
local PointTemplate = script.Parent.PointTemplate

PointTemplate.Parent = nil

local TweenService = game:GetService("TweenService")
local v11 = TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
local v12 = TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, 0)
local Debris = game:GetService("Debris")

function setup() -- line: 88
    -- upvalues: v1 (ref), Size (ref), growthFunction (copy), v2 (ref), ProgressBar (copy), n1 (ref), Sell (copy), Error (copy), v10 (ref), Sell2 (ref), CurrentCamera (copy), PointTemplate (copy), TweenService (copy), v11 (copy), v12 (copy), Debris (copy)
    Size = v1:WaitForChild("Size")
    n1 = growthFunction(Size.Value)
    Sell2 = v1:WaitForChild("Events"):WaitForChild("Sell")
    Size.Changed:Connect(function(p5) -- line: 94
        -- upvalues: v1 (ref), growthFunction (copy), v2 (ref), ProgressBar (copy), n1 (ref), Sell (copy), CurrentCamera (copy), PointTemplate (copy), TweenService (copy), v11 (copy), v12 (copy), Debris (copy)
        local v13 = growthFunction(p5)

        if v13 == 0 then
            Sell:Play()
        end

        local v14 = v13 - n1

        adjustBar(ProgressBar, v13 / v2)
        script.Parent.ProgressText.Text = commaValue(v13)
        n1 = v13

        local CurrentChunk = v1:FindFirstChild("CurrentChunk")

        if not (CurrentChunk and CurrentChunk.Value) then
            return
        end

        local Value = CurrentChunk.Value

        if Value.PrimaryPart then
            local v15 = CurrentCamera:WorldToScreenPoint(Value.PrimaryPart.Position)

            Vector2.new(v15.X, v15.Y)

            local clone = PointTemplate:Clone()

            clone.Text = "+" .. commaValue(v14)
            clone.Visible = true
            clone.Parent = script.Parent.Parent
            clone.Position = UDim2.new(0, v15.X, 0, v15.Y)
            clone.Size = UDim2.new(0, 0, 0, 0)

            local v16 = math.random() * 3.141592653589793 * 2
            local v18 = math.clamp(v14 ^ 0.2, 0, 4) * script.Parent.Parent.AbsoluteSize.X / 15
            local v19 = math.deg(v16)
            local v20 = if v19 > 180 then -1 else 1
            local tween = TweenService:Create(clone, v11, {
                Position = UDim2.new(0, v15.X + math.cos(v16) * v18, 0, v15.Y + math.sin(v16) * v18),
                Rotation = math.sqrt(v19 % 90) * v20
            })
            local tween2 = TweenService:Create(clone, v12, {
                Size = UDim2.new(1, 0, math.clamp(v14 ^ 0.2, 0, 4) * 0.05, 0)
            })

            tween:Play()
            tween2:Play()
            Debris:AddItem(clone, 3)
            tween2.Completed:Connect(function() -- line: 139
                -- upvalues: clone (copy)
                for i = 1, 15 do
                    task.wait()
                    clone.TextTransparency = i / 15
                    clone.UIStroke.Transparency = i / 15
                end
            end)
        end
    end)
    adjustBar(ProgressBar, n1 / v2)
    script.Parent.ProgressText.Text = n1
    v10 = false
    v1:WaitForChild("CurrentChunk").Changed:Wait()
    v1:WaitForChild("Events"):WaitForChild("Eat").OnClientEvent:Connect(function() -- line: 157
        -- upvalues: Error (copy)
        script.Parent.WarningText.Visible = true
        Error:Play()

        for i = 30, 1, -1 do
            local v24 = math.floor(i / 5)

            script.Parent.Position = UDim2.new(0.5, math.random(-v24, v24), 1, math.random(-v24, v24) - 10)
            task.wait()
        end

        script.Parent.Position = UDim2.new(0.5, 0, 1, -10)
    end)
end

script.Parent.SellButton.Activated:Connect(function() -- line: 170
    -- upvalues: Sell2 (ref)
    if Sell2 then
        Sell2:FireServer()
    else
        print("cant find sell event")
    end
end)
LocalPlayer.CharacterAdded:Connect(function(p6) -- line: 178
    -- upvalues: v1 (ref)
    v1 = p6
    setup()
end)
setup()
