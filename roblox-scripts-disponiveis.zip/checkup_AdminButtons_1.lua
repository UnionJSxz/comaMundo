-- https://lua.expert

game.ReplicatedStorage:WaitForChild("ServerSettings")

local LocalPlayer = game.Players.LocalPlayer
local AdminLevel = LocalPlayer:WaitForChild("AdminLevel")
local Value = AdminLevel.Value
local v1 = Value
local _ = game.ReplicatedStorage.Events.PurchaseEvent

if Value >= 2 then
    script.Parent.Visible = true
    script.Parent.Admin.Visible = true
    game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
else
    script.Parent.Admin.Visible = false
end

ownerId = 0

if game.ReplicatedStorage.ServerSettings.OwnerId.Value > 0 then
    ownerId = game.ReplicatedStorage.ServerSettings.OwnerId.Value
end

if ownerId == 0 then
    if Value < 1 then
        script.Parent.Visible = false
    else
        script.Parent.Visible = true
    end
elseif ownerId == LocalPlayer.UserId then
    script.Parent.Visible = true
end

game.ReplicatedStorage.ServerSettings.OwnerId.Changed:Connect(function(p1) -- line: 46
    -- upvalues: LocalPlayer (copy)
    if p1 == LocalPlayer.UserId then
        script.Parent.Visible = true
    end
end)
AdminLevel.Changed:Connect(function(p2) -- line: 53
    -- upvalues: v1 (ref)
    v1 = p2

    if p2 >= 2 then
        script.Parent.Visible = true
        script.Parent.Admin.Visible = true
    else
        script.Parent.Admin.Visible = false
    end

    if p2 >= 1 then
        script.Parent.Visible = true
    end
end)
script.Parent.ServerOptions.Activated:Connect(function() -- line: 69
    -- upvalues: v1 (ref)
    if v1 >= 1 then
        script.Parent.Parent.ServerSettings.Visible = not script.Parent.Parent.ServerSettings.Visible
    else
        script.Parent.Parent.ServerSettings.Visible = false
    end
end)
script.Parent.Admin.Activated:Connect(function() -- line: 79
    if not script.Parent.Parent:FindFirstChild("Youtuber Menu") then
        game.ReplicatedStorage.Events.AdminEvent:FireServer("RequestGui")
    end

    script.Parent.Parent["Youtuber Menu"].Visible = not script.Parent.Parent["Youtuber Menu"].Visible
end)
