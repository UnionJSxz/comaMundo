-- https://lua.expert

info = game.MarketplaceService:GetProductInfo(3717267806, Enum.InfoType.Product)
script.Parent.Price.Text = "" .. info.PriceInRobux
Color3.fromRGB(56, 197, 53)

local v1 = Color3.new(0.4, 0.4, 0.4)
local v2 = Color3.new(0.8, 0.8, 0.8)

Color3.new(1, 0.717647, 0.223529)
script.Parent.Buy.Activated:Connect(function() -- line: 11
    game.ReplicatedStorage.Events.PurchaseEvent:FireServer("Halloween Pack 2026")
end)

local connection = script.Parent.Button.Activated:Connect(function() -- line: 14
    game.ReplicatedStorage.Events.PurchaseEvent:FireServer("Halloween Pack 2026")
end)

function buttonOff(p1, p2) -- line: 18
    -- upvalues: v1 (copy), v2 (copy)
    p1.BackgroundColor3 = v1
    p1.UIStroke.Color = v1
    p1.Parent.BackgroundColor3 = v2

    if p2 then
        p1.Text = p2
    end
end

local UserThumbnailAsync = game.Players:GetUserThumbnailAsync(game.Players.LocalPlayer.UserId, Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size420x420)

script.Parent.ImageLabel.Image = UserThumbnailAsync

local clone = game.ReplicatedStorage:WaitForChild("Nametags"):WaitForChild("Watcher"):Clone()

clone.Parent = script.Parent.ImageLabel
clone.Size = UDim2.new(1, 0, 0.3, 0)
clone.Position = UDim2.new(0.5, 0, 0.05, 0)
clone:WaitForChild("UpperText").Text = game.Players.LocalPlayer.DisplayName

local TweenService = game:GetService("TweenService")
local v3 = TweenInfo.new(30, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, false, 0)

TweenService:Create(script.Parent:WaitForChild("Glow"), v3, {
    Rotation = 359
}):Play()

local HalloweenEvent = game.Players.LocalPlayer:WaitForChild("HalloweenEvent")

if HalloweenEvent then
    local HalloweenPackPurchased = HalloweenEvent:FindFirstChild("HalloweenPackPurchased")

    if HalloweenPackPurchased then
        if HalloweenPackPurchased.Value > 0 then
            buttonOff(script.Parent.Buy, "Purchased!")
            connection:Disconnect()
        end

        HalloweenPackPurchased.Changed:Connect(function(p3) -- line: 61
            -- upvalues: connection (copy)
            if p3 > 0 then
                buttonOff(script.Parent.Buy, "Purchased!")
                connection:Disconnect()
            end
        end)
    end
end
