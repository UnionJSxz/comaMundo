-- https://lua.expert

local Parent = script.Parent
local LocalPlayer = game.Players.LocalPlayer

function commaValue(p1) -- line: 4
    repeat
        local v2

        p1, v2 = string.gsub(p1, "^(-?%d+)(%d%d%d)", "%1,%2")
    until v2 == 0

    return p1
end

function formatTime(p2) -- line: 16
    local v4 = math.floor(p2 % 86400 / 3600)
    local v6 = math.floor(p2 % 3600 / 60)

    if v6 < 10 and v4 > 0 then
        v6 = "0" .. v6
    end

    local v8 = math.floor(p2 % 60)

    if v8 < 10 then
        v8 = "0" .. v8
    end

    if v4 > 0 then
        return v4 .. ":" .. v6 .. ":" .. v8
    end

    return v6 .. ":" .. v8
end

local v9 = false
local TimedRewards = LocalPlayer:WaitForChild("TimedRewards")
local RewardGrid = Parent.TimedRewards.RewardGrid
local Template = RewardGrid.Template

Template.Parent = nil

local Wheel = Parent.Spin.Spinner.Wheel
local Template2 = Wheel.Template

Template2.Parent = nil

local t1 = {}
local SoundModule = require(game.ReplicatedStorage.SoundModule)
local RewardInfo = require(game.ReplicatedStorage.RewardInfo)
local Error = SoundModule.newSound(script, "Error")
local Sell = SoundModule.newSound(script, "Sell")
local v10 = false

function loadRewards() -- line: 54
    -- upvalues: TimedRewards (copy), RewardGrid (copy), Template (copy), t1 (copy), v10 (ref)
    for _, child in ipairs(TimedRewards:GetChildren()) do
        local clone = Template:Clone()

        t1[child] = clone

        if child.Name == "MediumReward" then
            clone.ImageColor3 = Color3.new(0.882353, 0.682353, 0.0823529)
        elseif child.Name == "LargeReward" then
            clone.ImageColor3 = Color3.new(0.611765, 0.207843, 0.811765)
        elseif child.Name == "GiantReward" then
            clone.ImageColor3 = Color3.new(0.0431373, 0.972549, 0.941176)
        end

        clone.Activated:Connect(function() -- line: 65
            -- upvalues: child (copy), v10 (ref)
            if v10 then
                return
            end

            game.ReplicatedStorage.Events.RewardEvent:FireServer(child)
        end)
        clone.Parent = RewardGrid
    end
end

local Rewards = script.Parent.Parent:WaitForChild("SideButtons"):WaitForChild("Rewards")
local TimeText = Rewards:WaitForChild("TimeText")
local Alert = Rewards:WaitForChild("Alert")

Rewards.Activated:Connect(function() -- line: 76
    -- upvalues: Alert (copy)
    Alert.Visible = false
end)

local v11 = true
local v12 = false
local LastGroupSpin = LocalPlayer:WaitForChild("Stats").LastGroupSpin
local GroupInterval = RewardInfo.GroupInterval

function getSeed() -- line: 88
    -- upvalues: GroupInterval (copy)
    return (math.floor(os.time() / GroupInterval))
end

seed = getSeed()

local v14 = true

function updateTimes() -- line: 96
    -- upvalues: Parent (copy), v9 (ref), TimedRewards (copy), t1 (copy), v10 (ref), TimeText (copy), Alert (copy), v11 (ref), v12 (ref), LastGroupSpin (copy), GroupInterval (copy), v14 (ref)
    local n1 = 1e999

    for _, child in ipairs(TimedRewards:GetChildren()) do
        local v15 = t1[child]

        if child.Value == -1 then
            v15.Time.Text = "Claimed!"
            v15.ImageTransparency = 0.5
        elseif child.Value <= os.time() then
            v15.Time.Text = "Tap to claim!"
        else
            v15.Time.Text = formatTime(child.Value - os.time())
        end

        if child.Value >= 0 and child.Value < n1 then
            n1 = child.Value
        end
    end

    seed = getSeed()

    local v16 = os.difftime(GroupInterval * (seed + 1), os.time())

    if not v12 and not v10 then
        if LastGroupSpin.Value >= seed * GroupInterval then
            v14 = false

            if v9 then
                Parent.Spin.NextSpin.Visible = true
                Parent.Spin.NextSpin.Time.Text = formatTime(v16)
            else
                Parent.Spin.NextSpin.Visible = false
            end
        else
            v14 = true
            Parent.Spin.NextSpin.Visible = false
        end
    end

    TimeText.Visible = true

    if n1 == 1e999 then
        TimeText.Visible = false
    elseif os.time() <= n1 then
        v11 = true
        TimeText.Text = formatTime(n1 - os.time())
    else
        TimeText.Text = "Ready!"

        if v11 and not Parent.Visible then
            Alert.Visible = true
            v11 = false
        end
    end
end

function loadWheel() -- line: 143
    -- upvalues: Wheel (copy), Template2 (copy), RewardInfo (copy)
    for v17, v18 in ipairs(RewardInfo.SpinRewards) do
        local clone = Template2:Clone()

        clone.ItemImage.Image = v18[3]
        clone.Amount.Text = ""
        clone.Rotation = 30 + (v17 - 1) * 60
        clone.Parent = Wheel
    end
end

local n2 = 0

Parent.Spin.Button.Activated:Connect(function() -- line: 157
    -- upvalues: Parent (copy), v9 (ref), Error (copy), v10 (ref), v14 (ref), n2 (ref)
    if v10 then
        return
    end

    if v9 and v14 then
        game.ReplicatedStorage.Events.SpinEvent:FireServer()

        return
    end

    Error:Play()
    n2 += 1

    local v19 = n2

    Parent.Spin.Locked.Like.TextColor3 = Color3.new(1, 0, 0)
    Parent.Spin.Locked.Join.TextColor3 = Color3.new(1, 0, 0)
    Parent.Spin.NextSpin.Time.TextColor3 = Color3.new(1, 0, 0)
    Parent.Spin.NextSpin.Next.TextColor3 = Color3.new(1, 0, 0)
    wait(3)

    if v19 == n2 then
        Parent.Spin.Locked.Like.TextColor3 = Color3.new(1, 1, 1)
        Parent.Spin.Locked.Join.TextColor3 = Color3.new(1, 1, 1)
        Parent.Spin.NextSpin.Time.TextColor3 = Color3.new(1, 1, 1)
        Parent.Spin.NextSpin.Next.TextColor3 = Color3.new(1, 1, 1)
    end
end)

local TweenService = game:GetService("TweenService")

TweenInfo.new(RewardInfo.SpinTime, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0)

local connection

game.ReplicatedStorage.Events.SpinEvent.OnClientEvent:Connect(function(p3) -- line: 190
    -- upvalues: Wheel (copy), RewardInfo (copy), v10 (ref), v12 (ref), TweenService (copy), connection (ref)
    if connection then
        connection:Disconnect()
        connection = nil
    end

    v10 = true
    v12 = true

    local v20 = math.random(10, 50) - 180
    local v21 = 3600 + p3 * 60 - v20

    Wheel.Rotation = 0

    local n3 = 0
    local SpinTime = RewardInfo.SpinTime
    local n4 = 0

    connection = game["Run Service"].Heartbeat:Connect(function(p4) -- line: 207
        -- upvalues: v21 (copy), n3 (ref), SpinTime (copy), n4 (ref), Wheel (copy), v12 (ref), TweenService (copy), connection (ref)
        n3 = math.min(n3 + p4, SpinTime)
        n4 = TweenService:GetValue(n3 / SpinTime, Enum.EasingStyle.Quint, Enum.EasingDirection.Out) * v21
        Wheel.Rotation = n4 % 360

        if n3 ~= SpinTime then
            return
        end

        print("Ended!")
        connection:Disconnect()
        connection = nil
        v12 = false
    end)
end)

local tween = TweenService:Create(Parent.RewardNotif, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, 0), {
    Size = UDim2.new(1, 0, 0.2, 0)
})

game.ReplicatedStorage.Events.RewardEvent.OnClientEvent:Connect(function(p5, p6) -- line: 229
    -- upvalues: Parent (copy), Sell (copy), v10 (ref), tween (copy)
    Sell:Play()
    tween:Cancel()
    v10 = true

    if p5 == "Tokens" then
        Parent.RewardNotif.Price.TokenLabel.Visible = true
        Parent.RewardNotif.Price.CubeLabel.Visible = false
        Parent.RewardNotif.Price.TextColor3 = Color3.fromRGB(227, 125, 0)
    else
        Parent.RewardNotif.Price.TokenLabel.Visible = false
        Parent.RewardNotif.Price.CubeLabel.Visible = true
        Parent.RewardNotif.Price.TextColor3 = Color3.fromRGB(241, 205, 2)
    end

    Parent.RewardNotif.Visible = true
    Parent.RewardNotif.Price.Text = commaValue(p6)
    Parent.RewardNotif.Size = UDim2.new(1, 0, 0, 0)
    tween:Play()
    tween.Completed:Wait()
    wait(2)
    Parent.RewardNotif.Visible = false
    v10 = false
end)
Parent.Done.Activated:Connect(function() -- line: 252
    script.Parent.Visible = false
end)
loadRewards()
loadWheel()

local v23 = os.time()

while true do
    wait(0.2)

    if v23 < os.time() then
        v23 = os.time()
        updateTimes()

        if not v9 then
            local function v24() -- line: 266
                -- upvalues: Parent (copy), LocalPlayer (copy), v9 (ref)
                if LocalPlayer:IsInGroup(10587104) then
                    v9 = true
                    Parent.Spin.Locked.Visible = false
                else
                    Parent.Spin.Locked.Visible = true
                end
            end

            pcall(v24)
        end
    end
end
