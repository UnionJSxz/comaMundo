-- https://lua.expert

info = game.MarketplaceService:GetProductInfo(3443110792, Enum.InfoType.Product)
script.Parent.Price.Text = "" .. info.PriceInRobux
Color3.fromRGB(56, 197, 53)
Color3.new(0.4, 0.4, 0.4)
Color3.new(0.8, 0.8, 0.8)
Color3.new(1, 0.717647, 0.223529)
script.Parent.Buy.Activated:Connect(function() -- line: 11
    game.ReplicatedStorage.Events.PurchaseEvent:FireServer("Candy Rain")
end)
script.Parent.Button.Activated:Connect(function() -- line: 14
    game.ReplicatedStorage.Events.PurchaseEvent:FireServer("Candy Rain")
end)
