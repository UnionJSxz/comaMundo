-- https://lua.expert

local LocalPlayer = game.Players.LocalPlayer
local Preferences = LocalPlayer:WaitForChild("Preferences")
local Gamepasses = LocalPlayer:WaitForChild("Gamepasses")
local SetPreferences = game.ReplicatedStorage.Events.SetPreferences
local TextButton = script.Parent.Frame.Particles.TextButton
local TextButton2 = script.Parent.Frame.Music.TextButton
local TextButton3 = script.Parent.Frame.sfx.TextButton

require(game.ReplicatedStorage.ItemInfo)

local Done = script.Parent.Done
local v1 = Color3.fromRGB(209, 0, 0)
local v2 = Color3.fromRGB(82, 176, 77)
local v3 = Color3.fromRGB(95, 200, 88)
local v4 = Color3.fromRGB(208, 68, 72)

function turnOff(p1) -- line: 20
    -- upvalues: v1 (copy), v4 (copy)
    p1.BackgroundColor3 = v1
    p1.UIStroke.Color = v4
    p1.Text = "OFF"
end

function turnOn(p2) -- line: 26
    -- upvalues: v2 (copy), v3 (copy)
    p2.BackgroundColor3 = v2
    p2.UIStroke.Color = v3
    p2.Text = "ON"
end

function updateButtons() -- line: 32
    -- upvalues: Preferences (copy), TextButton (copy), TextButton2 (copy), TextButton3 (copy)
    if Preferences.Music.Value then
        turnOn(TextButton2)
    else
        turnOff(TextButton2)
    end

    if Preferences.SFX.Value then
        turnOn(TextButton3)
    else
        turnOff(TextButton3)
    end

    if Preferences.Particles.Value then
        turnOn(TextButton)
    else
        turnOff(TextButton)
    end

    for _, child in ipairs(script.Parent.Frame.Passes:GetChildren()) do
        local v5 = Preferences:FindFirstChild(child.Name)

        if v5 then
            if v5.Value then
                turnOn(child.TextButton)
            else
                turnOff(child.TextButton)
            end
        end
    end
end

TextButton.Activated:Connect(function() -- line: 59
    -- upvalues: Preferences (copy), SetPreferences (copy)
    SetPreferences:FireServer({
        Particles = not Preferences.Particles.Value
    })
end)
TextButton2.Activated:Connect(function() -- line: 63
    -- upvalues: Preferences (copy), SetPreferences (copy)
    SetPreferences:FireServer({
        Music = not Preferences.Music.Value
    })
end)
TextButton3.Activated:Connect(function() -- line: 67
    -- upvalues: Preferences (copy), SetPreferences (copy)
    SetPreferences:FireServer({
        SFX = not Preferences.SFX.Value
    })
end)
Preferences.Particles.Changed:Connect(updateButtons)
Preferences.Music.Changed:Connect(updateButtons)
Preferences.SFX.Changed:Connect(updateButtons)
Done.Activated:Connect(function() -- line: 75
    script.Parent.Visible = false
end)

local Template = script.Parent.Frame.Passes.Template

Template.Parent = nil

for _, child in ipairs(Preferences:GetChildren()) do
    local v6 = Gamepasses:FindFirstChild(child.Name)

    if v6 then
        local clone = Template:Clone()

        clone.Name = child.Name
        clone.Title.Text = string.upper(child.Name)
        clone.Parent = script.Parent.Frame.Passes

        if v6.Value then
            clone.Visible = true
        else
            clone.Visible = false
            v6.Changed:Once(function(p3) -- line: 93
                -- upvalues: clone (copy)
                if p3 then
                    clone.Visible = true
                end
            end)
        end

        clone.TextButton.Activated:Connect(function() -- line: 99
            -- upvalues: SetPreferences (copy), child (copy)
            SetPreferences:FireServer({
                [child.Name] = not child.Value
            })
        end)
        child.Changed:Connect(updateButtons)
    end
end

updateButtons()
