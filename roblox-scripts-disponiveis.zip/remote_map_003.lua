-- https://lua.expert

function buy() -- line: 1
    game.ReplicatedStorage.Events.PurchaseEvent:FireServer("Max Size")
    script.Parent.Parent.Parent.Parent.Parent.Visible = false
end

script.Parent.Button.Activated:Connect(buy)
script.Parent.Buy.Activated:Connect(buy)
info = game.MarketplaceService:GetProductInfo(1760728424, Enum.InfoType.Product)
script.Parent.Price.Text = "" .. info.PriceInRobux
