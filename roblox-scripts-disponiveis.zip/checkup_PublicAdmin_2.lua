-- https://lua.expert

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TimeUtil = require(ReplicatedStorage.TimeUtil)
local _ = game.ReplicatedStorage.Events.AdminEvent
local _ = game.Players.LocalPlayer.UserId
local Buttons = script.Parent:WaitForChild("Buttons")
local Template = Buttons:WaitForChild("Template")

Template.Parent = nil

local Title = script.Parent:WaitForChild("Title")
local LocalPlayer = game.Players.LocalPlayer
local v1

function loadCharacter(p1) -- line: 18
    -- upvalues: Buttons (copy), v1 (ref)
    v1 = p1
    v1.ChildAdded:Connect(function(p2) -- line: 20
        -- upvalues: Buttons (copy)
        local v2 = Buttons:FindFirstChild(p2.Name)

        if v2 then
            v2.BackgroundColor3 = Color3.fromRGB(82, 176, 77)
            v2.UIStroke.Color = Color3.fromRGB(82, 176, 77)
        end
    end)
    v1.ChildRemoved:Connect(function(p3) -- line: 27
        -- upvalues: Buttons (copy)
        local v3 = Buttons:FindFirstChild(p3.Name)

        if v3 then
            v3.BackgroundColor3 = Color3.fromRGB(100, 100, 100)
            v3.UIStroke.Color = Color3.fromRGB(100, 100, 100)
        end
    end)
end

loadCharacter(LocalPlayer.Character)
LocalPlayer.CharacterAdded:Connect(loadCharacter)

local t1 = {
    "Fly",
    "Grow",
    "Spawn Money",
    "Spawn Candy"
}
local n1 = 0

local function updateCooldown() -- line: 44
    -- upvalues: Title (copy), n1 (ref)
    if n1 > 0 then
        Title.Text = "COOLDOWN (" .. n1 .. ")"
    else
        Title.Text = "ADMIN MENU"
    end
end

ReplicatedStorage.ServerSettings.PublicAdmin.Changed:Connect(function(p4) -- line: 51
    -- upvalues: ReplicatedStorage (copy), LocalPlayer (copy)
    if not p4 and LocalPlayer.Character:FindFirstChild("Fly") then
        ReplicatedStorage.Events.PublicAdmin:FireServer()
    end
end)
script.Parent.Done.Activated:Connect(function() -- line: 60
    script.Parent.Visible = false
end)

for v4, v5 in ipairs(t1) do
    local clone = Template:Clone()

    clone.LayoutOrder = v4
    clone.Text = v5
    clone.Name = v5
    clone.Activated:Connect(function() -- line: 68
        -- upvalues: ReplicatedStorage (copy), Title (copy), LocalPlayer (copy), n1 (ref), v5 (copy)
        if v5 == "Fly" and LocalPlayer.Character:FindFirstChild("Fly") then
            ReplicatedStorage.Events.PublicAdmin:FireServer()

            return
        end

        if not (n1 > 0) then
            n1 = 2

            if n1 > 0 then
                Title.Text = "COOLDOWN (" .. n1 .. ")"
            else
                Title.Text = "ADMIN MENU"
            end

            ReplicatedStorage.Events.PublicAdmin:FireServer(v5)
        end
    end)
    clone.Parent = Buttons
end

TimeUtil.EverySecond:Connect(function() -- line: 85
    -- upvalues: Title (copy), n1 (ref)
    n1 -= 1

    if n1 > 0 then
        Title.Text = "COOLDOWN (" .. n1 .. ")"
    else
        Title.Text = "ADMIN MENU"
    end
end)
