# Depuração estática de eventos

Fonte: arquivos Lua já exportados. Nenhuma chamada foi enviada ao jogo, e os objetos e valores em execução não foram observados. Parâmetros `p1`, `v3` etc. são nomes preservados na saída descompilada, não contratos validados.

| Evento | Cliente → servidor | Servidor → cliente | Evidência local |
| --- | --- | --- | --- |
| `SetCubes` | sem argumentos | `p1` | `remote_map_001.lua:42`, `:54` |
| `CubesAdded` | não observado | `p5, p6` | `remote_map_001.lua:128` |
| `PurchaseEvent` | string literal ou valor de variável, conforme item | não observado | `remote_map_003.lua:4`, `remote_map_006.lua:193` |
| `SetPreferences` | tabela parcial, por exemplo `Particles` ou `Music` | não observado | `remote_map_007.lua:68` |
| `MapVote` | opção `v3` e posição normalizada da interface | `p1` | `remote_map_015.lua:58`, `:83` |
| `SpinEvent` | sem argumentos | `p3` | `remote_map_013.lua:185`, `:215` |
| `RewardEvent` | `child` | `p5, p6` | `remote_map_013.lua:77`, `:255` |
| `CrateOpen` | não observado | `p1, p2` | `remote_map_012.lua:90` |
| `SetNametag` | seleção, inclusive `Default` | não observado | `remote_map_017.lua:433` |
| `BuyCrate` | `v6` | não observado | `remote_map_017.lua:454` |
| `RequestTeleport` | `Mega` ou `Normal` | não observado | `remote_map_014.lua:5` |
| `AdminEvent` | comandos e, para anúncio, texto | não observado | `remote_map_009.lua:66`, `remote_map_011.lua:13` |
| `PublicAdmin` | nenhum argumento ou `v5` | não observado | `remote_map_019.lua:62`, `:92` |
| `ClaimNametag`, `ClaimMaxSize` | sem argumentos | não observado | `remote_map_018.lua:155`, `:245` |
| `HalloweenEvent` | `v3` | não observado | `remote_map_022.lua:77` |
| `SummonEvent` | `v29` após verificação local de tokens | não observado | `remote_map_006.lua:441` |
| personagem `Events.Eat` | não observado | sem argumentos no tratador | `remote_map_002.lua:151` |
| personagem `Events.Sell` | sem argumentos | não observado | `remote_map_002.lua:86`, `:170` |

## Pendências para reprodução

- Confirmar caminhos e classes de cada instância na sessão atual e descobrir referências ausentes dos arquivos disponíveis.
- Registrar, em um projeto de teste próprio, tipos e sequência de valores nos pontos de chamada e recebimento; não inferir o contrato completo a partir de nomes descompilados.
- Projetar validação e estado da nova implementação no servidor. Verificações feitas pela interface original não demonstram validação do servidor.
- Verificar se os scripts exportados em 15/11/2026 correspondem à versão atual do jogo.
